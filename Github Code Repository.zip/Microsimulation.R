# Microsimulation model based on the joint models
# Nov 4th 2024

### Change log:
##### In 2024_10_21 version
# 1. PV: problem: now performed a quasi half-cycle correction in the MCI state as the rounding up overstated the length of time in the MCI state. At some point we need to think of a way to extract exact times in each (pseudo) state. I left this for now as you said you would likely figure it out for a different project.
# 2. PV: found why I lost some people. It is because in out_p1_progressed you subset on before_progression. If someone progresses in the first cycle they were kicked out. Fixed this by including up until the progression line. Please tell me if this is actually wrong somewhere further along
# 3. PV: update i_age_1_scaled for the dementia phase
# 4. PV: made my own version of the markov trace plot

##### In 2024_10_25 version
# 1. PV: implemented drawing of random slopes conditional on the random intercept for those transitioning from MCI to dementia (random intercept is equal to their mmse at transition minus mmse at timepoint 0 based on fixed effects)
# 2. PV: had a long think about why the times in the MCI aren't increased a lot by the medication. It is because not the entire hazard is modified by the medication effect, but only the MMSE portion of it. The baseline hazard for example remains the same. Paradoxically, this means that the survival differences in the end are a lot bigger modifying the MMSE trajectory than if you only modify the hazard. This is likely because the modification of the MMSE trajectory at longer follow-up has non-linear effect on the hazard 
# 3. PV: Previously, the extension Weibull model didn't work with the slowed MMSE. Now it does
# 4. PV: added code which produces a 'variability' plot showing how the survival curves diverge based on 
# 5. PV: found out why some people didn't die in inst. It was because the wide_dataset setup was linked to the length of the pred_mmse_dead data (previously set to 15 years). If people were in dementia and institution for more than 15 years, their death time wasn't registered. Now I set the timers of everything to 30 and it should be good (though computationally bad)

##### In 2024_11_12 version
# 1. PV: Implemented 4 versions of slowing decline: A. proportionally reducing the hazard B. slowing MMSE individually, C. proportionally reducing MMSE by the average in the population. D. Slowing time in general

##### In 2024_11_14 version
# 1. PV: Changed the mechanisms of slowing decline into: A. Absolute reduction in MMSE. B. Slowing of MMSE. C. slowing of time with and without medication effect.
# 2. PV: created the option for treatment effects to last for a set duration
# 3. PV: Created the option for slowing of time not to effect death
# 4. PV: set up some code to export the wide data and mmse and survival probability data for plotting
# 5. PV: Added in the options to pre-select participants on age, sex, and decline speed
# 6. PV: added in the option for a non-MMSE treatment hypothesis next to slowing of MMSE (in affect a PH reduction)

##### In 2025_02_03 version
# 1. Removed r_mci_des calculation. This was a way of determining time in MCI directly from the sampled MCI times instead of from the cycles
# 2. Moved the jm_dem_inc file to 4 knots so it lined up with the (old) vcov I had exported. 
# 3. Fixed that the random effects in dementia weren't drawn seperately for the institutionalisation and death outcomes. This likely reduced variability in MMSe partners between individuals.

##### In 2025_02_12 version
# 1. Rewrote the code to do discrete event simulation with monthly time increments. Mean times are now also based on DSA
# 2. Took out the code that made the plot showing the transition probability per group of decline rate

## to do list:
# 0. Need to bring all the names of treatment options in line with to paper
# 0. Need to take out the stratification by decline speed

## to improve memory allocation pred_mmse_dead can be taken out if section 4.8 is not used, and all the rm(<file>) things can be uncommetend

#### 0. Preparatory steps ####
#### 0.1 Packages and libraries ####
if(!require("pacman")) install.packages("pacman")
pacman::p_load("mice", "MASS", "pracma", "tidyverse", "here", "splines", "readxl", "survival", "flexsurv"
               , "cowplot", "condMVNorm", "readr")
# install.packages("mice")
# install.packages("MASS")
# install.packages("pracma")
# install.packages("tidyverse")

library(MASS)
library(pracma) ##missed this package necessary to do use the cumtrapz function
library(mice)
library(tidyverse)
library(splines)
library(readxl)
library(here) ##pv: to set working direction to the project folder
library(readr)
library(condMVNorm)
library(cowplot) ##creates plot_grid

simulation_input <- read.csv(here("Simulation Output", "results sim.csv"))

this_sim <- simulation_input %>%
  subset(is.na(t_mci)) %>%
  slice(sample(n(),1))
# this_sim <- simulation_input %>%
#   subset(treat_impl == "none") %>% 
#   subset(is.na(limit_by_speed) & is.na(age_set) & is.na(sex_set)) %>% 
#   slice(1)

slowing <- this_sim$slowing
stop_mmse <- this_sim$stop_mmse
treat_impl <- this_sim$treat_impl
stop_time <- this_sim$stop_time
red_haz <- this_sim$red_haz
red_haz_perc <- this_sim$red_haz_perc
apply_to_death <- this_sim$apply_to_death
limit_by_speed <- this_sim$limit_by_speed
age_set <- this_sim$age_set
sex_set <- this_sim$sex_set
parametric_sens_analysis <- this_sim$parametric_sens
# parametric_sens_analysis <- "no"
sim_size <- 10000

# slowing <- 0.0
# stop_mmse <- 20
# treat_impl <- "none"
# stop_time <-  99
# apply_to_death <- "yes"
# limit_by_speed <- "no"

set.seed(as.numeric(Sys.time()))

#### 0.2 Load data ####
# Dutch mortality tables
mci_death_probability <- read_excel(here("Dutch Mortality Rates.xlsx"), sheet = "mortality_gender")

# dataset with patient characterisitcs
data_MCI <- readRDS(here("Simulation dataset", "example pt.RDS"))

# MCI parameters
mci_jm_lmm_fixed <- read_csv(here("Model Parameters" , "mci_jm_lmm_fixed.csv"))
mci_jm_tte_fixed <- read_csv(here("Model Parameters" , "mci_jm_tte_fixed.csv"))
mci_jm_re_var <- read_csv(here("Model Parameters", "mci_jm_re_var.csv"))
mci_ext_haz <- read_csv(here("Model Parameters", "mci_jm_ext_haz.csv"))
mci_ext_haz <- mci_ext_haz$x
mci_knots <- read_csv(here("Model Parameters", "mci_jm_knot_locations.csv"))
mci_knots <- mci_knots$x %>% as.numeric 
mci_specs <- read_csv(here("Model Parameters", "mci_jm_model_specs.csv"))
mci_jm_vcov <- read_csv(here("Model Parameters", "mci_jm_vcov.csv"))

# dementia parameters 
dem_inc_jm_lmm_fixed <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_inc_dem_lmm.xlsx"))
dem_inc_jm_tte_fixed <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_inc_dem_tte.xlsx"))
dem_inc_jm_re_var <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_inc_dem_re.xlsx"))
dem_inc_knots <- read_excel(here("Model Parameters/Dem Model Parameters" , "jm_inc_dem_knots.xlsx"), col_names = F)
dem_inc_knots <- dem_inc_knots[,1]
dem_knots <- dem_inc_knots
dem_inc_jm_specs <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_inc_dem_model_specs.xlsx"))
dem_inc_jm_vcov <- read.csv(here("Model Parameters/Dem Model Parameters", "jm_inc_dem_vcov.csv"), row.names = 1)

ext_model_dem <- read_excel(here("Model Parameters/Dem Model Parameters", "ext_dem_coef.xlsx"))
ext_model_dem_vcov <- read_excel(here("Model Parameters/Dem Model Parameters", "ext_dem_vcov.xlsx")) %>% dplyr::select(-name)

# institutionalisation --> mortality model
inst_mort_model <-  read_excel(here("Model Parameters/Dem Model Parameters", "inst_mort_coef.xlsx"))
inst_mort_vcov <-  read_excel(here("Model Parameters/Dem Model Parameters", "inst_mort_vcov.xlsx"))

#### 0.3 Formatting all the model-objects ##### 

#### 0.3.1 MCI joint model ##### 
gammas_bs <- mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "bs[:digit:]")] 
gammas   <- mci_jm_tte_fixed$est[1:2]
alphas <- mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "Assoct")]

betas_fixed <- mci_jm_lmm_fixed$est                                 
knots <- mci_knots                               
ord_spline <- mci_specs$ord 

form_beta_fixed <- paste0(" ~ ", mci_specs$form_beta_fixed) %>% as.formula                                         
form_gamma <- paste0(" ~ ", mci_specs$form_gamma) %>% as.formula

lmm <- list(form_beta_fixed = form_beta_fixed
            , betas_fixed = mci_jm_lmm_fixed$est)

tte <- list(knots = mci_knots
            , ord_spline =  mci_specs$ord 
            , gammas_bs = mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "bs[:digit:]")] 
            , gammas = mci_jm_tte_fixed$est[1:2]
            , alphas = mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "Assoct")]
            , form_gamma = form_gamma)

joint_model_mci <- list(lmm = lmm, tte = tte, re = mci_jm_re_var)

#### 0.3.2 Dem joint model ##### 

gammas_bs_inst <- dem_inc_jm_tte_fixed$value[str_detect(dem_inc_jm_tte_fixed$lbl, "bs[:digit:].inst")] 
gammas_bs_dead <- dem_inc_jm_tte_fixed$value[str_detect(dem_inc_jm_tte_fixed$lbl, "bs[:digit:].dead")] 

gammas   <- dem_inc_jm_tte_fixed$value[1:4]
alphas <- dem_inc_jm_tte_fixed$value[str_detect(dem_inc_jm_tte_fixed$lbl, "Assoct")]

betas_fixed <- dem_inc_jm_lmm_fixed$coef 
knots <- dem_inc_knots                               
ord_spline <- dem_inc_jm_specs$ord 

form_beta_fixed <- dem_inc_jm_specs$form_y
form_beta_fixed <- as.formula(paste0(" ~", as.character(form_beta_fixed)))
form_gamma <- as.formula(paste0(" ~ ", as.character(dem_inc_jm_specs$form_t)))

lmm <- list(form_beta_fixed = form_beta_fixed
            , betas_fixed = betas_fixed)
tte <- list(knots = knots
            , ord_spline = ord_spline
            , gammas_bs_inst = gammas_bs_inst
            , gammas_bs_dead = gammas_bs_dead
            , gammas = gammas
            , alphas = alphas
            , form_gamma = form_gamma)

joint_model_dem <- list(lmm = lmm, tte = tte, re= dem_inc_jm_re_var)


#### 0.3.3 Dem extension model ##### 
ext_shape_coef <- ext_model_dem$coef[str_detect(ext_model_dem$var_name, "shape")] 
ext_scale_coef  <- ext_model_dem$coef[!str_detect(ext_model_dem$var_name, "shape")] 
form_scale <- ext_model_dem$form_scale[1]
form_scale <- as.formula(paste0(" ~ ", form_scale))

ext_model <- list(ext_shape_coef = ext_shape_coef
                  , ext_scale_coef = ext_scale_coef
                  , form_scale = form_scale)

#### 0.3.4 Inst --> Death model ##### 
inst_mort_shape_coef <- inst_mort_model$coef[str_detect(inst_mort_model$var_name, "shape")] 
inst_mort_scale_coef  <- inst_mort_model$coef[!str_detect(inst_mort_model$var_name, "shape")] 
inst_mort_form_scale <- inst_mort_model$form_scale[1]
inst_mort_form_scale <- as.formula(paste0(" ~ ", inst_mort_form_scale))

inst_mort <- list(shape_coef= inst_mort_shape_coef
                  , scale_coef = inst_mort_scale_coef
                  , form_scale = inst_mort_form_scale)

#### 0.4 setting up function needed for straficifcation of data analysis is performed ####

### function that calculates decline speed by individual if stratification decline speed needs to be done
grouper_decline_speed <- function(data){
  betas_fixed <- mci_jm_lmm_fixed$est[str_detect(mci_jm_lmm_fixed$var, "fu_time_yrs")]  
  form_beta_fixed <- mci_specs$form_beta_fixed %>% str_replace(., "\\*", "\\:")
  form_beta_fixed <- paste0(" ~", form_beta_fixed)
  
  data$fu_time_yrs <- 1
  
  mm_beta  <- model.matrix(formula(form_beta_fixed), data = data)[,-1]
  
  data$slope <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
    data$re_slope * data$fu_time_yrs
  data %>% dplyr::select(id, slope) %>% return
}


#### 0.5 Modifying coefficients if there is parametric sensitivity analysis ####

## functions
coef_sampler_joint_model_mci <- function(joint_model, vcov){
  coefs <- c(
    joint_model$lmm$betas_fixed ## lmm betas
    , NA ## lmm sigma (residuals)
    , joint_model$tte$gammas ## tte gamma
    , joint_model$tte$alphas ## tte alpha
    , joint_model$tte$gammas_bs ## tte gamma_bs
    , joint_model$re)
  
  coefs <- coefs %>% unlist
  
  names(coefs) <- 
    c(rep("lmm", times = length(joint_model$lmm$betas_fixed))
      , "sigma"
      , rep("gammas", times = length(joint_model$tte$gammas))
      , rep("alphas", times = length(joint_model$tte$alphas))
      , rep("gammas_bs", times = length(joint_model$tte$gammas_bs))
      , names(joint_model$re)
    )
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  output_joint_model <- joint_model
  output_joint_model$lmm$betas_fixed <- sampled_coefs[names(sampled_coefs) == "lmm"]
  output_joint_model$tte$gammas_bs <- sampled_coefs[names(sampled_coefs) == "gammas_bs"]
  output_joint_model$tte$gammas <- sampled_coefs[names(sampled_coefs) == "gammas"]
  output_joint_model$tte$alphas <- sampled_coefs[names(sampled_coefs) == "alphas"]
  output_joint_model$re$int_var <- sampled_coefs[names(sampled_coefs)  == "int_var"]
  output_joint_model$re$slope_var <- sampled_coefs[names(sampled_coefs) == "slope_var"]
  output_joint_model$re$cov <- sampled_coefs[names(sampled_coefs) ==  "cov"]
  
  return(output_joint_model)
}

coef_sampler_joint_model_dem <- function(joint_model, vcov){
  coefs <- c(
    joint_model$lmm$betas_fixed ## lmm betas
    , NA ## lmm sigma (residuals)
    , joint_model$tte$gammas ## tte gamma
    , joint_model$tte$alphas ## tte alpha
    , joint_model$tte$gammas_bs_dead ## tte gamma_bs dead
    , joint_model$tte$gammas_bs_inst ## tte gamma_bs inst
    , joint_model$re)
  
  coefs <- coefs %>% unlist
  
  names(coefs) <- 
    c(rep("lmm", times = length(joint_model$lmm$betas_fixed))
      , "sigma"
      , rep("gammas", times = length(joint_model$tte$gammas))
      , rep("alphas", times = length(joint_model$tte$alphas))
      , rep("gammas_bs_dead", times = length(joint_model$tte$gammas_bs_dead))
      , rep("gammas_bs_inst", times = length(joint_model$tte$gammas_bs_inst))
      , names(joint_model$re)
    )
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  output_joint_model <- joint_model
  output_joint_model$lmm$betas_fixed <- sampled_coefs[names(sampled_coefs) == "lmm"]
  output_joint_model$tte$gammas_bs_dead <- sampled_coefs[names(sampled_coefs) == "gammas_bs_dead"]
  output_joint_model$tte$gammas_bs_inst <- sampled_coefs[names(sampled_coefs) == "gammas_bs_inst"]
  output_joint_model$tte$gammas <- sampled_coefs[names(sampled_coefs) == "gammas"]
  output_joint_model$tte$alphas <- sampled_coefs[names(sampled_coefs) == "alphas"]
  output_joint_model$re$re_int <- sampled_coefs[names(sampled_coefs)  == "re_int"]
  output_joint_model$re$re_slope <- sampled_coefs[names(sampled_coefs) == "re_slope"]
  output_joint_model$re$re_cov <- sampled_coefs[names(sampled_coefs) ==  "re_cov"]
  
  return(output_joint_model)
}

coef_sampler_weibull_models <- function(model, vcov){
  coefs <- model$coef
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  model$coef <- sampled_coefs
  
  return(model)
}

## selection 
temp <-
  rbind(dem_inc_jm_vcov[1:which(names(dem_inc_jm_vcov) == "Y.fu_time_yrs.scale.i_age_1."), ]
        , 0
        , dem_inc_jm_vcov[which(names(dem_inc_jm_vcov) == "Y.fu_time_yrs.diagnoseomsProbable.AD"):ncol(dem_inc_jm_vcov), ])
temp <- cbind(temp[, 1:which(names(temp) == "Y.fu_time_yrs.scale.i_age_1.")]
              , 0
              , temp[, which(names(temp) == "Y.fu_time_yrs.diagnoseomsProbable.AD"):ncol(temp)])
names(temp)[names(temp) == 0] <- "Y.fu_time_yrs.i_sexm"
dem_inc_jm_vcov <- temp

if(parametric_sens_analysis == "yes"){
  joint_model_mci <- coef_sampler_joint_model_mci(joint_model_mci, mci_jm_vcov)
  joint_model_dem <- coef_sampler_joint_model_dem(joint_model_dem, dem_inc_jm_vcov)
  ext_model_dem <- coef_sampler_weibull_models(ext_model_dem, ext_model_dem_vcov)
  inst_mort_model <- coef_sampler_weibull_models(inst_mort_model, inst_mort_vcov)
  
}

#### 1. Phase 1 MCI - AD ####
#### 1.1 Inputs for the prediction function ####
## samples a specified number of individuals from the input population                          
data <- data_MCI[sample(1:nrow(data_MCI), size = sim_size, replace = T),]
data$id <- 1:nrow(data)

##structures the random effect matrix
sigma <- matrix(NA, 2, 2)
sigma[1,1] <- joint_model_mci$re$int_var
sigma[1,2] <- sigma[2,1] <- joint_model_mci$re$cov
sigma[2,2] <- joint_model_mci$re$slope_var

##samples as many random intercepts and slopes as there are simulated individuals 
re <- mvrnorm(n = nrow(data), mu = c(0, 0), Sigma = sigma)

data$re_int <- re[, 1]
data$re_slope <- re[, 2]

##applying stratification
if(!is.na(limit_by_speed)){
  decl_speed <- grouper_decline_speed(data)
  decl_speed <- decl_speed %>%
    mutate(decl_group = Hmisc::cut2(slope, g =3)
           , decl_group = factor(decl_group, labels = c("Fast", "Medium", "Slow"))
    ) %>% dplyr::select(id, decl_group)
  id_select <- decl_speed %>% subset(decl_group == limit_by_speed) %>% pull(id)
  
  data <- data %>% subset(id %in% id_select)
  data$id <- 1:nrow(data)
}

if(!is.na(age_set)){
  data$i_age_1 <- age_set
  data$i_age_1_scaled <- (age_set - data$i_age_1_mean)/data$i_age_1_sd
}

if(!is.na(sex_set)){
  data$i_sex <- ifelse(sex_set == "f", 0, 1)
}

##specifies the timepoints on which survival probabilities need to be generated.
times <- seq(0, 30, length.out = 12 * 30 + 1)
times[1] <- 1e-3

##time at which the baseline hazard is extended. See function for expanation
t_split <- 10

#### 1.2 Prediction function MCI ####

### function to generate survival probabilities in the MCI stage
predict_mci <- function(data                            
                        , times                                    
                        , t_split
                        , joint_model
                        , slowing = slowing
                        , stop_mmse = stop_mmse
                        , id = "id"
                        , extension_base_haz
                        , treat_impl = "none"
                        , stop_time
                        , red_haz = "no"
                        , red_haz_perc = NA){
  
  ## extracting dynamic variables
  gammas_bs <- joint_model_mci$tte$gammas_bs  
  gammas   <- joint_model_mci$tte$gammas
  alphas <- joint_model_mci$tte$alphas 
  knots <- joint_model_mci$tte$knots                           
  ord_spline <- joint_model_mci$tte$ord_spline
  
  betas_fixed <- joint_model_mci$lmm$betas_fixed                                
  
  form_beta_fixed <- joint_model_mci$lmm$form_beta_fixed                                        
  form_gamma <- joint_model_mci$tte$form_gamma
  
  t_jm  <- times  
  data_long_jm <- data[rep(row.names(data), each = length(t_jm)),]

  ## calculating the baseline hazard of the jm part
  bspline_matrix  <- splineDesign(knots = knots, x = times, ord = ord_spline, outer.ok = T) 
  base_haz_jm_log <- bspline_matrix %*% cbind(gammas_bs) %>% as.numeric 
  
  ##as the baseline hazard is extended after the run time of the model, the baseline hazard after the end of the model (t_split), is filled in the with the extension_base_haz
  base_haz_jm_log[times >= t_split] <- extension_base_haz
  
  data_long_jm$base_haz_jm_log <- rep_len(base_haz_jm_log, length.out = nrow(data_long_jm)) 
  
  ## creating model matrix for lp (lp = linear prediction)
  mm_gamma <- data_long_jm %>% 
    model.matrix(formula(form_gamma), .) 
  mm_gamma <- mm_gamma[ , !(colnames(mm_gamma) %in% c("(Intercept)", "strata"))] 

  #calculated mmse curve with and without treatment effect
  if(treat_impl == "none"){
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))   
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
  } 
  if(slowing != 0 & treat_impl == "slow_mmse"){
    data_long_jm$fu_time_yrs <- rep_len(t_jm * (1 - slowing), length.out = nrow(data_long_jm))
    
    ##first calculate the full mmse curve with slowed time
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
    
    ##determine when stop criteria MMSE is reached
    data_long_jm <- data_long_jm %>%
      group_by(
        .[,{{id}}]
        # id
      ) %>%
      mutate(
        # Identify time and MMSE when stop_mmse is reached
        t_adj_at_stop = ifelse(any(pred_mmse <= stop_mmse),
                               min(fu_time_yrs[pred_mmse <= stop_mmse], na.rm = TRUE)
                               , max(times))
        
        #Identify if time at stop_mmse isn't after the stop_time
        , t_adj_at_stop = ifelse(t_adj_at_stop > stop_time
                                 , stop_time
                                 , t_adj_at_stop)
        , t_real_at_stop =  t_adj_at_stop / (1 - slowing)
        
        # Adjust time after the MMSE decline has reached the stop point
        ## From the point where the MMSE is lower than the stop criterium, it needs to 
        ## follow a normal decline speed. Adjustment for the "real"/original time
        ## at the index of the stop_mmse needs to be made.
        ## Note to self: to understand the logic draw it out with 33% slowing of a 0:3 time series
        , fu_time_yrs = if_else(fu_time_yrs >= t_adj_at_stop
                                , fu_time_yrs / (1 - slowing) - (t_real_at_stop - t_adj_at_stop)
                                , fu_time_yrs,
        )
      )
    
    mm_beta <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    # Now recalculate the MMSE using the adjusted time
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed) +
                                           data_long_jm$re_int +
                                           data_long_jm$re_slope * data_long_jm$fu_time_yrs)
    
    ##reset time variable
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))
  }
  
  ##truncate MMSE at real values
  data_long_jm$pred_mmse[data_long_jm$pred_mmse < 0] <- 0 
  data_long_jm$pred_mmse[data_long_jm$pred_mmse > 30] <- 30 
  
  ## calculating the linear predictor
  data_long_jm$lp_jm <- as.numeric(mm_gamma %*% cbind(gammas)) + data_long_jm$pred_mmse * alphas
  
  ## calculating hazard for the JM
  data_long_jm$haz <- NA
  data_long_jm$haz <- exp(data_long_jm$base_haz_jm_log + data_long_jm$lp_jm) 
  
  ##apply hazard reduction to overall hazard
  if(red_haz == "yes" & treat_impl != "none"){
    data_long_jm <- data_long_jm %>% 
      mutate(haz = if_else(pred_mmse >= stop_mmse
                        , haz * (1 - red_haz_perc)
                        , haz)
      )
  }
  
  ##sum the hazard over time for cumulative hazard
  data_long_jm <- data_long_jm %>% 
    group_by(
      .[,{{id}}]
    ) %>% 
    mutate(cumhaz = as.numeric(cumtrapz(fu_time_yrs, haz))) %>% 
    ungroup()
  
  ## survival prob jm 
  data_long_jm <- data_long_jm %>% mutate(surv_prob = as.numeric(exp(- cumhaz)))
  
  ##export specific variables
  data_return <- data_long_jm %>% 
      dplyr::select(id, fu_time_yrs, surv_prob, pred_mmse, i_age_1, i_sex, i_age_1_scaled, i_living)
  
  return(data_return)
}

#### 1.3 Predicting time to progression ####
pred_mci <- predict_mci(data = data, times = times, t_split = t_split
                        , slowing = slowing, stop_mmse = 0
                        , extension_base_haz = mci_ext_haz
                        , treat_impl = treat_impl
                        , stop_time = stop_time
                        , red_haz = red_haz
                        , red_haz_perc = red_haz_perc) 

## sample survival time to dementia by individual
pred_mci <- pred_mci %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%  
  ungroup() %>% 
  dplyr::select(id, fu_time_yrs, i_age_1, i_sex, i_living, pred_mmse) %>% 
  rename(time_mci_to_dementia = fu_time_yrs)

#### 1.4 Sampling time to death ####
# based on the Dutch mortality tables
data_expanded <- data %>%
  dplyr::select(id, i_age_1, i_sex) %>% 
  uncount(60) %>%                             # Duplicate each ID 10 times ##PV: 60?
  group_by(id) %>%                            # Group by ID
  mutate(age = i_age_1 + row_number() - 1,
         sex = if_else(i_sex == "m", 0, 1)) %>% 
  ungroup() %>% 
  filter(age < 100)

# set.seed(123) 
data_expanded <- left_join(data_expanded, mci_death_probability, by = c("age" = "age", "sex" = "gender")) %>% 
  dplyr::select(id, i_age_1, age, sex, chance_death) %>% 
  mutate(chance = runif(nrow(data_expanded), min = 0, max = 1),
         death = if_else(chance_death > chance, 1, 0))

data_died <- group_by(data_expanded, id) %>% 
  filter(death == 1) %>% 
  slice(1) %>% ##extract first time someone has died
  ungroup()

data_died <- data_died %>% 
  mutate(time_mci_to_death = age - i_age_1 + 0.5 ##0.5 does the half-cycle correction
         ) %>% dplyr::select(id, time_mci_to_death)
#### 1.5 Phase 1 output ####
# Postprocessing states for a Markov trace
out_p1 <- left_join(pred_mci, data_died, by = "id") %>% 
  mutate(
    ##for some people death is not sampled before 100, for those people fix death time to be time between age at baseline and 100.
    time_mci_to_death = ifelse(is.na(time_mci_to_death)
                               , 100 - i_age_1
                               , time_mci_to_death) 
    , died_in_mci = if_else(time_mci_to_dementia < time_mci_to_death, 0, 1)##decide on outcome
    
    , time_in_mci = if_else(died_in_mci == 1, time_mci_to_death
                            , time_mci_to_dementia)
    ) 

rm(pred_mci)

#### 2. Phase 2 AD ####
#### 2.1 Inputs for the prediction function ####

##input data
input_phase2 <- out_p1 %>% subset(died_in_mci == 0) %>% 
  ##set-up the variables that were caried over for the new function
  mutate(i_living = ifelse(i_living != "zelfstandig met partner/gezin", 0, 1), 
         i_age_1 = i_age_1 + time_in_mci, ##increase age by time in MCI
         i_age_1_scaled = (i_age_1 - 64.85) / 7.5,
         diagnoseoms = 0, ##fix diagnosis at baseline to be MCI
         ) %>% 
  dplyr::select(id, time_in_mci, i_age_1, i_sex, i_age_1_scaled, i_living, diagnoseoms
                , pred_mmse) %>%
  rename(mmse_baseline = pred_mmse ##mmse at start of dementia
         ) 

## set timepoints
t_split <- 4 ##when the joint model transitions to the extension model
times <- seq(0, 30, length.out = 12 * 30 + 1)
times[1] <- 1e-3 ##set the first time point of both the joint model and extension model to be just a little over zero for the b-spline matrix
times[times == 4] <- times[times == 4] + times[1] 

#### 2.2 Prediction function AD (requires vectorization) ####
weibull_haz <- function(t, scale, shape){shape/scale * (t/scale) ^ (shape - 1)}

dementia_draw_random_effects <- function(data, joint_model, from_mci = "yes"){
  ## extracting dynamic variables
  betas_fixed <- joint_model$lmm$betas_fixed                               
  
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        

    ##generation random intercept/slope
  if(from_mci == "yes"){
    ##Calculate intercept MMSE so I can subtract it from the calculations
    mm_lme <- model.matrix(form_beta_fixed, data = mutate(data, fu_time_yrs = 0)) # What does the model.matrix function do? Create a subset of data to fit the model formula 
    
    data$mmse_intercept <- as.numeric(mm_lme %*% cbind(betas_fixed))
    
    ##random intercept is equal to difference between MMSE at transition and MMSE based on fixed effect
    data$re_int <- data$mmse_baseline - data$mmse_intercept
    
    ##gives the mean value the slope is supposed to have based on the random intercept
    lt_mat <- ltMatrices(matrix(c(joint_model$re$re_int, joint_model$re$re_cov, joint_model$re$re_slope)), diag = T) 
    cond_mean <- cond_mvnorm(chol = lt_mat, which_given = 1, given = matrix(data$re_int, ncol = nrow(data)))
    data$re_slope <- rnorm(nrow(data), mean = cond_mean$mean, sd = sqrt(cond_mean$chol))
    
    data <- data %>% dplyr::select(-mmse_intercept)
    
  }else{
    sigma <- matrix(NA, 2, 2)
    sigma[1,1] <- joint_model$re$re_int
    sigma[1,2] <- sigma[2,1] <- joint_model$re$re_cov
    sigma[2,2] <- joint_model$re$re_slope
    
    re_dem <- mvrnorm(nrow(data), mu = c(0,0), Sigma = sigma)
    
    data$re_int <- re_dem[,1]
    data$re_slope <- re_dem[,2]
  }
  
  return(data)
}

prediction_dementia <- function(data                                     
                                , joint_model                                                       
                                , times                                    
                                , slowing = 0
                                , stop_mmse = 20
                                , t_split = 4                                  
                                , id = "id"                                       
                                , ext_model
                                , pred_part = "inst" ##set if time to institutionalisation or death are calculated
                                , from_mci = "yes" ##if yes, new random effects are generated conditional on the mmse at conversion
                                , treat_impl = "none"
                                , stop_time
                                , red_haz = "no"
                                , red_haz_perc = NA
){
  ## extracting dynamic variables
  gammas_bs <- joint_model$tte[[paste0("gammas_bs_", pred_part)]]
  
  gammas   <- joint_model$tte$gammas    
  
  alphas <- ifelse(pred_part == "inst", sum(joint_model$tte$alphas), joint_model$tte$alphas[1])
  
  betas_fixed <- joint_model$lmm$betas_fixed                               
  
  knots <- joint_model$tte$knots[[1]]
  ord_spline <- joint_model$tte$ord_spline                                        
  
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        
  form_gamma <- joint_model$tte$form_gamma
  
  ## extension model variables
  ext_shape_coef <- ext_model$ext_shape_coef 
  ext_scale_coef  <- ext_model$ext_scale_coef
  form_scale <- ext_model$form_scale
  
  t_jm  <- times  # times for the joint model
  t_ext <- times # times for the extension model
  
  ## turning data into long format jm
  data_long_jm <- data[rep(row.names(data), each = length(t_jm)),] ##typo fixed length

  ## calculating the baseline hazard of the jm part
  bspline_matrix  <- splineDesign(knots = knots, x = times, ord = ord_spline, outer.ok = T) 
  base_haz_jm_log <- bspline_matrix %*% cbind(gammas_bs) %>% as.numeric 
  
  data_long_jm$base_haz_jm_log <- rep_len(base_haz_jm_log, length.out = nrow(data_long_jm)) 
  
  ## creating model matrix for lp (lp = linear prediction)
  mm_gamma <- data_long_jm %>% 
    mutate(strata = if_else(pred_part == "inst", 1, 0)) %>% 
    model.matrix(formula(form_gamma), .) 
  mm_gamma <- mm_gamma[ , !(colnames(mm_gamma) %in% c("(Intercept)", "strata"))] 
  
  ##check if from MCI to adjust the stopping time
  if(from_mci == "yes"){
    data_long_jm$stop_time <- stop_time - data_long_jm$time_in_mci
    data_long_jm$stop_time <- ifelse(data_long_jm$stop_time < 0
                                     , 0 
                                     , data_long_jm$stop_time)
  }
  
  #calculated mmse curve in several cases of slowing
  if(treat_impl == "none"){
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))   
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
  } 
  if(slowing != 0 & treat_impl == "slow_mmse"){
    data_long_jm$fu_time_yrs <- rep_len(t_jm * (1 - slowing), length.out = nrow(data_long_jm))
    
    ##first calculate the full mmse curve with slowed time
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
    
    ##determine when stop criteria MMSE is reached
    data_long_jm <- data_long_jm %>%
      group_by(
        # .[,{{id}}]
        id
      ) %>%
      mutate(
        # Identify time and MMSE when stop_mmse is reached
        t_adj_at_stop = ifelse(any(pred_mmse <= stop_mmse),
                               min(fu_time_yrs[pred_mmse <= stop_mmse], na.rm = TRUE)
                               , max(times))
        
        #Identify if time at stop_mmse isn't after the stop_time
        , t_adj_at_stop = ifelse(t_adj_at_stop > stop_time
                                 , min(fu_time_yrs[fu_time_yrs > stop_time]) ##select first timepoint after the stop time to be the time after which slowing doesn't occur anymore
                                 , t_adj_at_stop)
        , t_real_at_stop =  t_adj_at_stop / (1 - slowing)
        
        # Adjust time after the MMSE decline has reached the stop point
        ## From the point where the MMSE is lower than the stop criterium, it needs to 
        ## follow a normal decline speed. Adjustment for the "real"/original time
        ## at the index of the stop_mmse needs to be made.
        ## Note to self: to understand the logic draw it out with 33% slowing of a 0:3 time series
        , fu_time_yrs = if_else(fu_time_yrs >= t_adj_at_stop
                                , fu_time_yrs / (1 - slowing) - (t_real_at_stop - t_adj_at_stop)
                                , fu_time_yrs,
        )
      )
    
    mm_beta <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    # Now recalculate the MMSE using the adjusted time
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed) +
                                           data_long_jm$re_int +
                                           data_long_jm$re_slope * data_long_jm$fu_time_yrs)
    
    ##reset time variable
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))
  }
  
  ##truncate MMSE at natural bounds
  data_long_jm$pred_mmse[data_long_jm$pred_mmse < 0] <- 0 
  data_long_jm$pred_mmse[data_long_jm$pred_mmse > 30] <- 30 
  
  ## calculating the linear predictor for the jm
  data_long_jm$lp_jm <- as.numeric(mm_gamma %*% cbind(gammas)) + data_long_jm$pred_mmse * alphas 
  
  ## calculating hazard for the JM part
  data_long_jm$haz <- NA
  data_long_jm$haz <- exp(data_long_jm$base_haz_jm_log + data_long_jm$lp_jm) 

  # hazard from the extension model
  ## First getting out the MMSE at split point from the JM and merging in into the data
  data_jm_mmse <- data_long_jm %>% 
    group_by(
      .[,{{id}}]
      ) %>% 
    slice(which.min(abs(fu_time_yrs - t_split))) %>% ungroup %>% 
    dplyr::select(id, pred_mmse) %>% rename(v_mmse = pred_mmse)
  
  data <- data %>% merge(., data_jm_mmse)
  
  # calculating shape and scale for Weibull
  data <- data %>% mutate(strata = pred_part)
  
  mm1  <- data.frame(c1 = 1, c2 = ifelse(data$strata == "inst", 1, 0)) 
  if(length(ext_shape_coef) == 1) {mm1 <- data.frame(c1 = 1)} 
  
  data$ext_shape <- as.matrix(mm1) %*% cbind(ext_shape_coef) %>%  as.numeric %>% exp 
  
  data$ext_scale <- data %>% 
    mutate(strata = if_else(pred_part == "inst", 1, 0)
           , i_age_1 = i_age_1 + t_split) %>% 
    model.matrix(form_scale, data = .) %*% cbind(ext_scale_coef) %>%  as.numeric %>% exp

  ## turning data into long format gamma model
  data_long_ext <- data[rep(row.names(data), each = length(t_ext)),] 
  data_long_ext$fu_time_yrs <- rep_len(t_ext, length.out = nrow(data_long_ext))
  
  data_long_ext$haz <- 
    weibull_haz(t = data_long_ext$fu_time_yrs,
                shape = data_long_ext$ext_shape,
                scale = data_long_ext$ext_scale)
  
  ## adjusting the time in the extension model the reflect time from dementia start
  data_long_ext <- data_long_ext %>% 
    mutate(fu_time_yrs = fu_time_yrs + t_split)
  
  ## binding rows together
  data_long_ext <- data_long_ext %>% rename(pred_mmse = v_mmse)
  col_select <- c("id", "fu_time_yrs", "haz")
  data_long <- rbind(data_long_jm[data_long_jm$fu_time_yrs < t_split, col_select]
                     , data_long_ext[data_long_ext$fu_time_yrs <= max(times), col_select]) 
  
  ## Merge in the predicted mmse at each time point
  data_long <- data_long_jm %>% dplyr::select(id, fu_time_yrs, pred_mmse) %>% 
    merge(data_long, ., by = c("id", "fu_time_yrs"))
  
  ## Reduce hazard if this treatment option is selected
  if(red_haz == "yes" & treat_impl != "none"){
    data_long <- data_long %>% 
      mutate(haz = ifelse(pred_mmse >= stop_mmse
                          , haz * (1 - red_haz_perc)
                          , haz)
      )
  }
  
  ## calculate cumulative hazard by person
  data_long <- data_long %>% 
    arrange(id, fu_time_yrs) %>% 
    group_by(
      .[,{{id}}]
    ) %>%
    mutate(cumhaz = as.numeric(cumtrapz(fu_time_yrs, haz))) %>% 
    ungroup()
  
  ## Calculate survival probability
  data_long <- data_long %>% mutate(surv_prob = as.numeric(exp(- cumhaz)))
  
  ## merge the survival data with some patient characteristics needed
  data <- data %>% 
    dplyr::select(id, i_age_1, i_sex, i_living) %>% 
    merge(data_long, ., by = "id", all.y = T) %>% arrange(id, fu_time_yrs)
  
  ##select what data to output
  data <- data %>% 
    dplyr::select(id, fu_time_yrs, surv_prob, i_age_1, i_sex, pred_mmse, i_living, haz)
  
  return(data)
  
}

#### 2.3 Predicting time to institutionalization  ####
input_phase2 <- dementia_draw_random_effects(input_phase2, joint_model_dem
                                             , from_mci = "yes")

pred_inst <- prediction_dementia(input_phase2,                                     
                                 joint_model_dem,
                                 times = times, 
                                 slowing = slowing,
                                 stop_mmse = stop_mmse,
                                 t_split = t_split, # = 4; years after which the model is split? ## yeah, timepoint at which the years are split
                                 id = "id",                                       
                                 ext_model = ext_model,                               
                                 pred_part = "inst"
                                 , treat_impl = treat_impl
                                 , stop_time = stop_time
                                 , red_haz = red_haz
                                 , red_haz_perc = red_haz_perc
                                 , from_mci = "yes"
)

## need the mmse values to calculate the time in dementia stages, so retaining the long formated data
pred_mmse_inst <- pred_inst

##sampling survival times
pred_inst <- pred_inst %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ungroup 

#### 2.4 Predicting time to death in the community  ####
pred_dead <- prediction_dementia(input_phase2,                                     
                                 joint_model_dem, ##small type 
                                 times = times, 
                                 slowing = slowing, ##at a slowing of 1 there is no progression.
                                 stop_mmse = stop_mmse,
                                 t_split = t_split,# = 4; years after which the model is split? ## yeah, timepoint at which the years are split
                                 id = "id",                                       
                                 ext_model = ext_model,                                # m_gamma
                                 pred_part = "dead"
                                 , treat_impl = 
                                   ifelse(apply_to_death == "yes",
                                          treat_impl
                                          , "none")
                                 , stop_time = stop_time
                                 , red_haz = red_haz
                                 , red_haz_perc = red_haz_perc
                                 , from_mci = "yes"
)


# pred_mmse_dead <- pred_dead                                                          # HMB: Saves the MMSE curve to be used to allocate people in the severity states

##sampling survival times
pred_dead <- pred_dead %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ungroup 

#### 2.5 Phase 2 output ####
pred_dead <- mutate(pred_dead, ttdeath = fu_time_yrs) %>%     
  dplyr::select(id, ttdeath)

pred_inst <- mutate(pred_inst, ttinst = fu_time_yrs) %>% 
  dplyr::select(-fu_time_yrs, -surv_prob, -pred_mmse, -haz)

out_p2 <- full_join(pred_dead, pred_inst, by = c("id")) %>% 
  mutate(institutionalized = if_else(ttinst < ttdeath, 1, 0)
         , time_in_dementia = ifelse(institutionalized == 1, ttinst, ttdeath)) 

t_incr <- mean(diff(times)) ## average length of an increment of time
pred_dementia_stages <- pred_mmse_inst %>% 
  group_by(id) %>% 
  summarise(time_mild_dem = sum(pred_mmse > 20) * t_incr
            , time_mod_dem = sum(pred_mmse <= 20 & pred_mmse >= 10) * t_incr
            , time_sev_dem = sum(pred_mmse < 10) * t_incr
  )

out_p2 <- merge(out_p2, pred_dementia_stages, by = "id")
##fix the dementia stages based on MMSE to conform to the dementia length
out_p2 <- out_p2 %>% 
  mutate(
    ##if total time in dementia is dementia is shorter than time in mild dementia based on MMSe, time in mild dementia is set to total time in dementia
    time_mild_dem = ifelse(time_mild_dem > time_in_dementia
                                , time_in_dementia
                                , time_mild_dem)
    ##if people transition out of dementia during moderate dementia, their mild dementia time is equal to total dementia time minus mild dementia time
         , time_mod_dem = ifelse((time_mild_dem + time_mod_dem) > time_in_dementia
                                 , time_in_dementia - time_mild_dem
                                 , time_mod_dem)
    ##if people transition out of dementia during severe dementia, their svere dementia time is equal to total dementia time minus mild and moderate dementia time
    
         , time_sev_dem = ifelse((time_mild_dem + time_mod_dem + time_sev_dem) > time_in_dementia
                                 , time_in_dementia - (time_mild_dem + time_mod_dem)
                                 , time_sev_dem)
    
    ##fix so times cannot be negative
    , time_mod_dem = ifelse(time_mod_dem < 0, 0, time_mod_dem)
    , time_sev_dem = ifelse(time_sev_dem < 0, 0, time_sev_dem)
  )

rm(pred_mmse_inst)

#### 3. Phase 3 Death in the institution ####
#### 3.1 Inputs for the prediction function ####
# data
input_phase3 <- out_p2 %>% subset(institutionalized == 1) %>%
  dplyr::select(id, i_age_1, i_living, i_sex, ttinst) %>% 
  mutate(age_update = floor(i_age_1 + ttinst))

#### 3.2 Prediction function AD  
prediction_institution <- function(data
                                   , model
                                   , times
                                   , id = "id"){
  mm <- model.matrix(model$form_scale, data)
  data$lp <- as.numeric(mm %*% model$scale_coef)
  
  data <- data[rep(row.names(data), each = length(times)),]
  data$fu_time_yrs <- rep_len(times, length.out = nrow(data))
  data$surv_prob <- 1 - pweibull(data$fu_time_yrs, shape = exp(model$shape_coef), scale = exp(data$lp))
  
  # data$fu_time_yrs <- rweibull(nrow(data), shape = exp(model$shape_coef), scale = exp(data$lp))
  return(data)
}

#### 3.3 Predicting time to death in the institution ####
pred_inst_mort <- prediction_institution(data = input_phase3, model = inst_mort
                                         , times = seq(0, 30, length.out = 12 * 30 + 1)
                                         , id = "id")

pred_inst_dead <- pred_inst_mort %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ungroup() %>%
  mutate(ttdeath_inst = fu_time_yrs
         , age_at_end_fu = age_update + fu_time_yrs
  ) %>% 
  dplyr::select(id, ttdeath_inst) %>% rename(time_in_inst = ttdeath_inst)

#### 4. Postprocessing ####

#### 4.1 Preparing dataset with all the stage times for everyone
dt_stage_times <- out_p2 %>% 
  dplyr::select(id, time_in_dementia, time_mild_dem, time_mod_dem, time_sev_dem, institutionalized) %>% 
  merge(out_p1, ., by = "id", all = T)
dt_stage_times <- pred_inst_dead %>% 
  merge(dt_stage_times, ., by = "id", all = T)

dt_stage_times <- dt_stage_times %>% 
  dplyr::select(id, died_in_mci, institutionalized, time_in_mci, time_in_dementia
                , time_mild_dem, time_mod_dem, time_sev_dem, time_in_inst)

##all NA's indicate never reached a stage or spent 0 time there
dt_stage_times <- dt_stage_times %>% 
  mutate_all(., function(x) ifelse(is.na(x), 0, x))

#### 4.2 Prepare cycle based data for output used in plots
## turn person by person stage times into number of people per cycle
expand_trajectory <- function(df) {
  df %>%
    rowwise() %>%
    mutate(years = list(0:ceiling(sum(c_across(starts_with("time_")))))) %>%
    unnest(years) %>%
    mutate(
      stage = case_when(
        years <= time_in_mci ~ "community_mci",
        years <= time_in_mci + time_mild_dem ~ "community_mild",
        years <= time_in_mci + time_mild_dem + time_mod_dem ~ "community_moderate",
        years <= time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem ~ "community_severe",
        years <= time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem + time_in_inst ~ "institutionalization",
        years > time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem + time_in_inst ~ "death"
      )
    ) %>%
    group_by(years, stage) %>%
    summarise(count = n(), .groups = "drop") %>%
    pivot_wider(names_from = stage, values_from = count, values_fill = 0)
}

# Apply function
cycle_based_data <- expand_trajectory(dt_stage_times)

##need to fix death counting in post
cycle_based_data <- cycle_based_data %>% 
  mutate(death = nrow(data) - community_mci - community_mild - community_moderate - community_severe - institutionalization)

##order of cycle columns can change, so fixing it
cycle_based_data <- cycle_based_data %>% 
  dplyr::select(years, community_mci, community_mild, community_moderate, community_severe
                , institutionalization, death)

#### 4.3 Summary statistics of mean time and when people died
summary_output_sim <- dt_stage_times %>% 
  summarise(t_mci = mean(time_in_mci)
            , t_mild = mean(time_mild_dem)
            , t_moderate = mean(time_mod_dem)
            , t_severe = mean(time_sev_dem)
            , t_inst = mean(time_in_inst)
            , start_n = nrow(data)
            , dead_mci = sum(died_in_mci)
            , dead_dem_com = nrow(data) - dead_mci - sum(institutionalized))

#### 4.4 Outputting simulation results ####

#### summary statistics
this_sim <- this_sim %>% 
  mutate(t_mci = summary_output_sim$t_mci
         , t_mild = summary_output_sim$t_mild 
         , t_moderate = summary_output_sim$t_moderate
         , t_severe = summary_output_sim$t_severe
         , t_inst = summary_output_sim$t_inst
         , start_n = nrow(data)
         , dead_mci = summary_output_sim$dead_mci
         , dead_dem_com = summary_output_sim$dead_dem_com)

simulation_input <- read.csv(here("Simulation Output", "results sim.csv"))

simulation_input[simulation_input$sim_num == this_sim$sim_num,] <- this_sim

write.csv(simulation_input, here("Simulation Output", "results sim.csv"), row.names = F)
 
#### cycle data for plotting
sim_characters <- this_sim %>%
  dplyr::select(slowing, stop_mmse, treat_impl, stop_time, red_haz, red_haz_perc
                , apply_to_death, limit_by_speed
                , age_set, sex_set, parametric_sens, sim_num)
# wide_data$cycle <- 0:(nrow(wide_data)-1)
export_wide <- cbind(cycle_based_data, sim_characters)
present_wide_data <- read.csv(here("Simulation Output", "cycle sim data.csv"))
export_wide <- rbind(present_wide_data, export_wide)
write.csv(export_wide, here("Simulation Output", "cycle sim data.csv"), row.names = F)

#### mmse and surv data for plotting
# pred_mmse_inst <- pred_mmse_inst %>%
#   rename(surv_prob_inst = surv_prob
#          , haz_inst = haz)
# pred_mmse_dead <- pred_mmse_dead %>%
#   rename(surv_prob_dead = surv_prob
#          , haz_dead = haz) %>%
#   dplyr::select(id, fu_time_yrs, surv_prob_dead, haz_dead)
# pred_mmse_dem <- merge(pred_mmse_inst, pred_mmse_dead, by = c("id",  "fu_time_yrs"))
# 
# temp_dem <- pred_mmse_dem %>%
#   dplyr::select(id, fu_time_yrs, pred_mmse, surv_prob_inst, surv_prob_dead, haz_inst
#                 , haz_dead) %>%
#   mutate(stage = "dem") %>% rename(fu_time_yrs_dem = fu_time_yrs)
# temp_mci <- pred_mci %>%
#   dplyr::select(id, fu_time_yrs, pred_mmse, surv_prob) %>%
#   mutate(stage = "mci") %>% rename(fu_time_yrs_mci = fu_time_yrs
#                                    , surv_prob_conv = surv_prob)
# mmse_surv_export <- merge(temp_dem, temp_mci, all = T)
# 
# mmse_surv_export <- mmse_surv_export %>% arrange(id, fu_time_yrs_dem, fu_time_yrs_mci)
# sim_characters <- this_sim %>%
#   dplyr::select(slowing, stop_mmse, treat_impl, stop_time
                  # , red_haz, red_haz_perc
                  # , apply_to_death, limit_by_speed
#                 , age_set, sex_set, sim_num)
# mmse_surv_export <- cbind(mmse_surv_export, sim_characters)
# 
# library(data.table)
# # fwrite(mmse_surv_export, here("Simulation Output", "mmse and surv sim data.csv"), row.names = F
# #        , append = T)

