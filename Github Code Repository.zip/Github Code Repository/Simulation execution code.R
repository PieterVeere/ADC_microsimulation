if(!require("pacman")) install.packages("pacman")
pacman::p_load("here", "dplyr")
## change from 2024-10-25
## 1. added the aria side-effect variables

##change in 2025-07-01
## 1. made aria and treatment mci and dementia specific so their utilities can be attributed to specifc stages if needed

##setting up simulation data.frame
simulation_input <- data.frame(sim_num = NA, slowing = NA, stop_mmse = NA)

##slowing to be investigated
slow_opt <- c(0.3)

##stop criteria to be investigated - MMSE value
stop_opt <- c(
  20
)

##treatment options
treat_opt <- c("none", "slow_mmse")

##model approach
model_opt <- c("jm"
               # , "weibull"
)

##treatment heterogeneity distribution
treat_heterogeneity_opt <- c("leaky"
                             # , "all_or_nothing"
)

##
red_haz_opt <- c("no")
red_haz_perc <- c(0)

##apply to detah
apply_to_death <- c("yes")

##stop time options
stop_time <- c(99)

## age options
age_options <- c(NA
                 , 60, 70, 80
)

## sex options
sex_options <- c(NA
                 , "m", "f"
)

## speed options
speed_options <- c(NA
                   # , "Slow", "Medium", "Fast"
)

## Parametric
# parametric_sens_opt <- c("no")
# parametric_sens_opt <- c("all", "mci", "dem", "inst")

## aria_parameters
simulate_aria <- "no"
aria_discount_opt <- c(1)
aria_discount_delay_opt <- 1.5
aria_duration_opt <- 3/12
aria_all_observed_opt <- "no"

#treatment waning
treat_waning_opt <- c(0)

## Voluntary treatment cessation
simulate_voluntary_discontinuation <- "no"
vol_treat_discont_perc_opt <- c(0)

## TTC or Continuous dosing scenario
treatment_scenario_opt <- c("continuous")
time_to_clear <- c(1.5) ##this need to align with the aria_discount_delay_opt somewhat as the discounting is set to 1 in this scenario

##number of simulations per scenario - about 100 000 simulated individuals needed for stable stage times
n_sim <- 10

simulation_input <- 
  expand.grid(slowing = slow_opt, stop_mmse = stop_opt, treat_impl = treat_opt
              , stop_time = stop_time
              , red_haz = red_haz_opt
              , red_haz_perc = red_haz_perc
              , apply_to_death = apply_to_death
              , limit_by_speed = speed_options
              , age_set = age_options
              , sex_set = sex_options
              # , parametric_sens = parametric_sens_opt
              , simulate_aria = simulate_aria
              , aria_discount = aria_discount_opt
              , aria_discount_delay = aria_discount_delay_opt
              , aria_duration = aria_duration_opt
              , aria_all_observed = aria_all_observed_opt
              , sim_vol_disc = simulate_voluntary_discontinuation
              , vol_treat_discont_perc = vol_treat_discont_perc_opt
              , treat_waning = treat_waning_opt
              , treatment_scenario = treatment_scenario_opt
              , time_to_clear = time_to_clear
              , treat_heterogeneity = treat_heterogeneity_opt
              , model_approach = model_opt)
simulation_input <- simulation_input %>%
  mutate(slowing = if_else(treat_impl == "none", 0, slowing)) %>% ##
  subset(!(red_haz == "yes" & red_haz_perc == 0)) %>% ##take out option where no slowing is applied
  subset(!(red_haz == "no" & red_haz_perc != 0)) %>% ##take out option where no slowing is applied
  subset(!(treat_impl == "none" & red_haz == "yes" )) %>% ##can't reduce hazard in no-treatment simulation
  filter(is.na(age_set) & is.na(sex_set) |
           is.na(age_set) & is.na(limit_by_speed) |
           is.na(sex_set) & is.na(limit_by_speed)) %>% ## to limit simulations reduce overlapping subpopulation 
  #getting rid of various treatment and side-effect options for the no-treatment scenario
  subset(!(treat_impl == "none" &
             (aria_discount != 1 | vol_treat_discont_perc != 0 | 
                treat_waning != 0 | treat_heterogeneity != "leaky" | stop_mmse != 20))) %>% 
  # #all_or_nothing only possible for red_haz == "no"
  subset(!(treat_heterogeneity == "all_or_nothing" & red_haz == "yes")) %>% 
  ##no more reduction hazard with a jm modelling approach
  subset(!(model_approach == "jm" & red_haz == "yes")) %>% 
  ##no weibull model approach without a red_haz as long as it is a treatment scenario
  subset(!(model_approach == "weibull" & red_haz == "no" & treat_impl == "slow_mmse"))

simulation_input <- simulation_input %>% 
  mutate(simulate_aria = if_else(treat_impl == "none", "no", simulate_aria)) %>% 
  mutate(
    sim_vol_disc = if_else(treat_impl == "none", "no", sim_vol_disc)
    , vol_treat_discont_perc  = if_else(sim_vol_disc == "no", 0, vol_treat_discont_perc)
    , sim_vol_disc = if_else(vol_treat_discont_perc == 0, "no", sim_vol_disc)
    , treat_waning = if_else(treat_impl == "none", 0, treat_waning)) 

simulation_input <- simulation_input[rep(1:nrow(simulation_input), each = n_sim), ]
simulation_input$sim_num <- 1:nrow(simulation_input)

simulation_results <- simulation_input

simulation_results$t_mci <- NA
simulation_results$t_mild <- NA
simulation_results$t_moderate <- NA
simulation_results$t_severe <- NA
simulation_results$t_inst <- NA
simulation_results$start_n <- NA
simulation_results$dead_mci <- NA
simulation_results$dead_dem_com <- NA
##aria + treatment MCI
simulation_results$aria_mild_asymptomatic_mci <- NA
simulation_results$aria_moderate_asymptomatic_mci <- NA
simulation_results$aria_severe_asymptomatic_mci <- NA
simulation_results$aria_mild_symptomatic_mci <- NA
simulation_results$aria_moderate_symptomatic_mci <- NA
simulation_results$aria_severe_symptomatic_mci <- NA
simulation_results$aria_n_mri_mci <- NA
simulation_results$aria_death_mci <- NA
simulation_results$t_treated_mci <- NA
##aria + treatment dem
simulation_results$aria_mild_asymptomatic_dem <- NA
simulation_results$aria_moderate_asymptomatic_dem <- NA
simulation_results$aria_severe_asymptomatic_dem <- NA
simulation_results$aria_mild_symptomatic_dem <- NA
simulation_results$aria_moderate_symptomatic_dem <- NA
simulation_results$aria_severe_symptomatic_dem <- NA
simulation_results$aria_n_mri_dem <- NA
simulation_results$aria_death_dem <- NA
simulation_results$t_treated_dem <- NA

simulation_results <- simulation_results[1,]
simulation_results$sim_num <- NA

write.csv(simulation_input, here("Simulation Output", "simulation input.csv"), row.names = F)
write.csv(simulation_results, here("Simulation Output", "results sim.csv"), row.names = F)
# write.csv(simulation_input, here("Simulation Output", "results sim dem.csv"), row.names = F)

##supplying a single example patient for the simulations
mci_sim_pt <-  data.frame(i_sex = c("m", "f"), i_age_1 = 65, i_age_1_scaled = 0
                        , csf_ptau_log_scaled = 0, csf_ab42_scaled = 0, m_mta_lr = 1, v_mmse = 27
                        , i_living = "zelfstandig met partner/gezin" ##Dutch for living with partner/family)
)
saveRDS(mci_sim_pt, here("Simulation Dataset", "example pt.RDS")) ##you have to change the filename in the "Microsimulation.R" file accordingly 

sim_results <- read.csv(here("Simulation Output", "results sim.csv"))

##parallelisation possible to speed up simulations. Each run takes approximately 4-5gb ram, so size cores accordingly
# registerDoParallel(cores = 4)
n_iter <- sum(is.na(sim_results$t_mci) ) + 4

foreach(1:n_iter, .packages = "here") %dopar%{
  source(here("Microsimulation.R"), echo = T)
}

doParallel::stopImplicitCluster()

sim_results <- read.csv(here("Simulation Output", "results sim.csv"))
sim_results$t_mci %>% is.na %>% table
sim_results <- sim_results %>% mutate(t_dem_com = t_mild + t_moderate + t_severe)

## check output
sim_results %>% 
  # subset(start_n != 1000) %>% 
  subset(is.na(limit_by_speed) & is.na(age_set) & is.na(sex_set)) %>% 
  group_by(slowing, treat_impl, apply_to_death, red_haz, red_haz_perc) %>% 
  summarise(t_mci = mean(t_mci, na.rm =T)
            , t_mild = mean(t_mild, na.rm = T)
            , t_moderate = mean(t_moderate, na.rm = T)
            , t_severe = mean(t_severe, na.rm = T)
            , t_dem_com = mean(t_mild + t_moderate + t_severe, na.rm = T)
            , t_total = mean(t_mci + t_mild + t_moderate + t_severe + t_inst, na.rm = T)
            , t_inst = mean(t_inst, na.rm = T)
            , dead_mci = mean(dead_mci, na.rm = T)
            , dead_dem_com = mean(dead_dem_com, na.rm = T)
            , n_inst = mean(start_n - dead_mci - dead_dem_com, na.rm = T)) %>% data.frame

