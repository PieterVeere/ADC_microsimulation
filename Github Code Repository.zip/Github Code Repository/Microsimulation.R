# Microsimulation model based on the joint models

#### 0. Preparatory steps ####
#### 0.1 Packages and libraries ####
if(!require("pacman")) install.packages("pacman")
pacman::p_load("mice", "MASS", "pracma", "tidyverse", "here", "splines", "readxl", "survival", "flexsurv"
               , "condMVNorm", "readr", "Hmisc", "slider")

simulation_input <- read.csv(here("Simulation Output", "simulation input.csv"))
sim_results <-  read.csv(here("Simulation Output", "results sim.csv"))
sim_completed <- sim_results %>% subset(!is.na(t_mci)) %>% pull(sim_num)

source(here("Microsimulation_functions.R"), echo = F) 

this_sim <- simulation_input %>%
  subset(!(sim_num %in% sim_completed)) %>%
  slice(sample(n(),1))
this_sim

slowing <- this_sim$slowing %>% as.numeric
stop_mmse <- this_sim$stop_mmse
treat_impl <- this_sim$treat_impl
stop_time <- this_sim$stop_time
red_haz <- this_sim$red_haz
red_haz_perc <- this_sim$red_haz_perc %>% as.numeric

apply_to_death <- this_sim$apply_to_death
limit_by_speed <- this_sim$limit_by_speed
age_set <- this_sim$age_set
sex_set <- this_sim$sex_set
# parametric_sens_analysis <- this_sim$parametric_sens
waning <- this_sim$treat_waning # 0.1 ##proportion per year decline in effect, so for 0.1 a 30% slowing goes to 27% after a year.
sim_aria <- this_sim$simulate_aria
aria_discount <- this_sim$aria_discount #"yes" ##how quickly does that ARIA occurrence decrease
aria_discount_delay <- this_sim$aria_discount_delay # 1.5 ##for the trial duration aria probabilities are kept stable; in years
aria_duration <- this_sim$aria_duration #3/12 ##duration of ARIA in years
aria_all_observed <- this_sim$aria_all_observed ##if no, then a visitation scheme based on DOI: 10.14283/jpad.2023.30 is applied to see if the aria is observed. All symptomatic aria are assumed to be detected
sim_vol_discontinuation <- this_sim$sim_vol_disc ##simulate if people stop their treatment voluntarily, proportion per year
vol_disc_rate <- this_sim$vol_treat_discont_perc ##10% probability per year to voluntarily stop treatment
sim_size <- 10000
treatment_scenario <- this_sim$treatment_scenario
time_to_clear <- this_sim$time_to_clear
treat_heterogeneity <- this_sim$treat_heterogeneity
model_approach <- this_sim$model_approach

set.seed(as.numeric(Sys.time()))

#### 0.2 Load data ####
# Dutch mortality tables
mci_death_probability <- read_excel(here("Dutch Mortality Rates.xlsx"), sheet = "mortality_gender")

# dataset with patient characterisitcs
data_MCI <- readRDS(here("Simulation dataset", "example pt.rds"))

# MCI parameters
mci_jm_lmm_fixed <- read_csv(here("Model Parameters" , "mci_jm_lmm_fixed.csv"))
mci_jm_tte_fixed <- read_csv(here("Model Parameters" , "mci_jm_tte_fixed.csv"))
mci_jm_re_var <- read_csv(here("Model Parameters", "mci_jm_re_var.csv"))
mci_ext_haz <- read_csv(here("Model Parameters", "mci_jm_ext_haz.csv"))
mci_ext_haz <- mci_ext_haz$x
mci_knots <- read_csv(here("Model Parameters", "mci_jm_knot_locations.csv"))
mci_knots <- mci_knots$x %>% as.numeric 
mci_specs <- read_csv(here("Model Parameters", "mci_jm_model_specs.csv"))
mci_jm_vcov <- read_csv(here("Model Parameters", "mci_jm_vcov.csv"))

# dementia parameters 
dem_jm_lmm_fixed <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_dem_lmm.xlsx"))
dem_jm_tte_fixed <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_dem_tte.xlsx"))
dem_jm_re_var <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_dem_re.xlsx"))
dem_knots <- read_excel(here("Model Parameters/Dem Model Parameters" , "jm_dem_knots.xlsx"), col_names = F)
dem_knots <- dem_knots[,1]
dem_knots <- dem_knots
dem_jm_specs <- read_excel(here("Model Parameters/Dem Model Parameters", "jm_dem_model_specs.xlsx"))

ext_model_dem <- read_excel(here("Model Parameters/Dem Model Parameters", "ext_dem_coef.xlsx"))
ext_model_dem_vcov <- read_excel(here("Model Parameters/Dem Model Parameters", "ext_dem_vcov.xlsx")) %>% dplyr::select(-name)

# institutionalisation --> mortality model
inst_mort_model <- read_excel(here("Model Parameters/Dem Model Parameters", "inst_mort_coef.xlsx"))
inst_mort_vcov <- read_excel(here("Model Parameters/Dem Model Parameters", "inst_mort_vcov.xlsx"))

# hazard models
dem_haz_coefs <- read_excel(here("Model Parameters/Dem Model Parameters", "hazard_model_dem_coef.xlsx"))

mci_haz_coefs <- read.csv(here("Model Parameters", "mci_wei_coef.csv"))
mci_haz_vcov <- read.csv(here("Model Parameters", "mci_wei_vcov.csv"))

#### 0.3 Formatting all the model-objects ##### 

#### 0.3.1 MCI joint model ##### 
gammas_bs <- mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "bs[:digit:]")] 
gammas   <- mci_jm_tte_fixed$est[1:2]
alphas <- mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "Assoct")]

betas_fixed <- mci_jm_lmm_fixed$est                                 
knots <- mci_knots                               
ord_spline <- mci_specs$ord 

form_beta_fixed <- paste0(" ~ ", mci_specs$form_beta_fixed) %>% as.formula                                         
form_gamma <- paste0(" ~ ", mci_specs$form_gamma) %>% as.formula

lmm <- list(form_beta_fixed = form_beta_fixed
            , betas_fixed = mci_jm_lmm_fixed$est)

tte <- list(knots = mci_knots
            , ord_spline =  mci_specs$ord 
            , gammas_bs = mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "bs[:digit:]")] 
            , gammas = mci_jm_tte_fixed$est[1:2]
            , alphas = mci_jm_tte_fixed$est[str_detect(mci_jm_tte_fixed$var, "Assoct")]
            , form_gamma = form_gamma)

joint_model_mci <- list(lmm = lmm, tte = tte, re = mci_jm_re_var)

#### 0.3.2 Dem joint model ##### 

# gammas_bs_inst <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "bs[:digit:].inst")] 
# gammas_bs_dead <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "bs[:digit:].dead")] 

# gammas   <- dem_jm_tte_fixed$value[1:4]
# alphas <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "Assoct")]

gammas_bs_inst <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "bs[:digit:].inst")] 
gammas_bs_dead <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "bs[:digit:].dead")] 
gammas   <- dem_jm_tte_fixed$value[1:3]
alphas <- dem_jm_tte_fixed$value[str_detect(dem_jm_tte_fixed$lbl, "Assoct")]

betas_fixed <- dem_jm_lmm_fixed$coef 
knots <- dem_knots                               
ord_spline <- dem_jm_specs$ord 

form_beta_fixed <- dem_jm_specs$form_y
form_beta_fixed <- as.formula(paste0(" ~", as.character(form_beta_fixed)))
form_gamma <- as.formula(paste0(" ~ ", as.character(dem_jm_specs$form_t)))

lmm <- list(form_beta_fixed = form_beta_fixed
            , betas_fixed = betas_fixed)
tte <- list(knots = knots
            , ord_spline = ord_spline
            , gammas_bs_inst = gammas_bs_inst
            , gammas_bs_dead = gammas_bs_dead
            , gammas = gammas
            , alphas = alphas
            , form_gamma = form_gamma)

joint_model_dem <- list(lmm = lmm, tte = tte, re= dem_jm_re_var)

#### 0.3.3 Dem extension model ##### 
ext_shape_coef <- ext_model_dem$coef[str_detect(ext_model_dem$var_name, "shape")] 
ext_scale_coef  <- ext_model_dem$coef[!str_detect(ext_model_dem$var_name, "shape")] 
form_scale <- ext_model_dem$form_scale[1]
form_scale <- as.formula(paste0(" ~ ", form_scale))

ext_model <- list(ext_shape_coef = ext_shape_coef
                  , ext_scale_coef = ext_scale_coef
                  , form_scale = form_scale)

#### 0.3.4 Inst --> Death model ##### 
inst_mort_shape_coef <- inst_mort_model$coef[str_detect(inst_mort_model$var_name, "shape")] 
inst_mort_scale_coef  <- inst_mort_model$coef[!str_detect(inst_mort_model$var_name, "shape")] 
inst_mort_form_scale <- inst_mort_model$form_scale[1]
inst_mort_form_scale <- as.formula(paste0(" ~ ", inst_mort_form_scale))

inst_mort <- list(shape_coef= inst_mort_shape_coef
                  , scale_coef = inst_mort_scale_coef
                  , form_scale = inst_mort_form_scale)


#### 0.3.5 MCI --> Dem model ####
wei_shape_coef <- mci_haz_coefs$coef[str_detect(mci_haz_coefs$var_name, "shape")] 
wei_scale_coef  <- mci_haz_coefs$coef[!str_detect(mci_haz_coefs$var_name, "shape")] 
form_scale <- mci_haz_coefs$form_scale[1]
form_scale <- as.formula(paste0(" ~ ", form_scale))

mci_hazard_model <- list(wei_shape_coef = wei_shape_coef
                         , wei_scale_coef = wei_scale_coef
                         , form_scale = form_scale)


#### 0.3.5 Dem --> Inst | Death model ####
wei_shape_coef <- dem_haz_coefs$coef[str_detect(dem_haz_coefs$var_name, "shape")] 
wei_scale_coef  <- dem_haz_coefs$coef[!str_detect(dem_haz_coefs$var_name, "shape")] 
form_scale <- dem_haz_coefs$form_scale[1]
form_scale <- as.formula(paste0(" ~ ", form_scale))

dem_hazard_model <- list(wei_shape_coef = wei_shape_coef
                         , wei_scale_coef = wei_scale_coef
                         , form_scale = form_scale)

#### 1. Phase 1 MCI - AD ####
#### 1.1 Inputs for the prediction function ####
## samples a specified number of individuals from the input population                          
data <- data_MCI[sample(1:nrow(data_MCI), size = sim_size, replace = T),]
data$id <- 1:nrow(data)

##structures the random effect matrix
sigma <- matrix(NA, 2, 2)
sigma[1,1] <- joint_model_mci$re$int_var
sigma[1,2] <- sigma[2,1] <- joint_model_mci$re$cov
sigma[2,2] <- joint_model_mci$re$slope_var

##samples as many random intercepts and slopes as there are simulated individuals 
re <- mvrnorm(n = nrow(data), mu = c(0, 0), Sigma = sigma)

data$re_int <- re[, 1]
data$re_slope <- re[, 2]

##applying stratification
if(!is.na(limit_by_speed)){
  decl_speed <- grouper_decline_speed(data)
  decl_speed <- decl_speed %>%
    mutate(decl_group = Hmisc::cut2(slope, g =3)
           , decl_group = factor(decl_group, labels = c("Fast", "Medium", "Slow"))
    ) %>% dplyr::select(id, decl_group)
  id_select <- decl_speed %>% subset(decl_group == limit_by_speed) %>% pull(id)
  
  data <- data %>% subset(id %in% id_select)
  data$id <- 1:nrow(data)
}

if(!is.na(age_set)){
  data$i_age_1 <- age_set
  data$i_age_1_scaled <- (age_set - data$i_age_1_mean)/data$i_age_1_sd
}

if(!is.na(sex_set)){
  data$i_sex <- ifelse(sex_set == "f", 0, 1)
}

##specifies the timepoints on which survival probabilities need to be generated.
times <- seq(0, 30, length.out = 12 * 30 + 1)

##time at which the baseline hazard is extended. See function for expanation
t_split <- 10

#### 1.2 Prediction function MCI ####

aria_visitation_scheme <- c(10/52, 14/52, 28/52, 52/52)

#### 1.3 Predicting time to progression ####

if(sim_vol_discontinuation == "yes"){
  data <- vol_treat_disc(data, discount_prob = vol_disc_rate
                         , treatment_scenario = treatment_scenario, time_to_clear = time_to_clear)
}

if(sim_aria == "yes"){
  mci_aria <- aria_side_effects(data = data
                                , aria_prob_mat = aria_prob
                                , times = times
                                , from_mci = "no"
                                , aria_discount = aria_discount
                                , aria_discount_delay = aria_discount_delay
                                , length_aria = aria_duration
                                , aria_all_observed = aria_all_observed, aria_visitation_scheme = aria_visitation_scheme
                                , sim_vol_discontinuation = sim_vol_discontinuation
                                , treatment_scenario = treatment_scenario, time_to_clear = time_to_clear)
}

if(treat_heterogeneity == "all_or_nothing"){
  data <- treatment_heterogeneity_sampler(data, slowing = slowing)
}

if(model_approach == "jm"){
  pred_mci_long <- predict_mci(data = data, times = times, t_split = t_split
                               , slowing = slowing, stop_mmse = 0
                               , extension_base_haz = mci_ext_haz
                               , treat_impl = treat_impl
                               , stop_time = stop_time
                               , red_haz = red_haz
                               , red_haz_perc = red_haz_perc
                               , joint_model = joint_model_mci
                               , waning = waning
                               , side_effect = sim_aria, side_effect_data = mci_aria
                               , sim_vol_discontinuation = sim_vol_discontinuation
                               , treat_heterogeneity = treat_heterogeneity
  ) 
}

if(model_approach == "weibull"){
  pred_mci_long <- predict_weibull_time(
    data
    , model = mci_hazard_model
    , joint_model = joint_model_mci
    , times = times, 
    slowing = slowing,
    stop_mmse = stop_mmse,
    id = "id"                                      
    , treat_impl = treat_impl
    , stop_time = stop_time
    , red_haz = red_haz
    , red_haz_perc = red_haz_perc
    , dementia_sim = "no"
    , waning = waning
    , side_effect = sim_aria, side_effect_data = mci_aria
    , treat_heterogeneity = treat_heterogeneity
  )
  
  mmse_at_conversion <- predict_mci(data = data, times = times, t_split = t_split
                                    , slowing = slowing, stop_mmse = 0
                                    , extension_base_haz = mci_ext_haz
                                    , treat_impl = "none"
                                    , stop_time = stop_time
                                    , red_haz = red_haz
                                    , red_haz_perc = red_haz_perc
                                    , joint_model = joint_model_mci
                                    , waning = waning
                                    , side_effect = "no", side_effect_data = mci_aria
                                    , sim_vol_discontinuation = sim_vol_discontinuation
                                    , treat_heterogeneity = treat_heterogeneity
  ) 
  mmse_at_conversion <- mmse_at_conversion %>% group_by(id) %>%
    slice(which.min(abs(surv_prob - runif(1)))) %>%  
    ungroup() %>% pull(pred_mmse)
  
}

## sample survival time to dementia by individual
pred_mci <- pred_mci_long %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%  
  ungroup() %>% 
  dplyr::select(id, fu_time_yrs, i_age_1, i_sex, i_living
                , any_of(c("pred_mmse", "treated", "aria_count", "aria_severity"
                           , "time_on_treatment", "t_dead_aria", "treat_all_or_nothing"))) %>% 
  rename(time_mci_to_dementia = fu_time_yrs) 

if(model_approach == "weibull"){
  pred_mci$pred_mmse <- mmse_at_conversion
}


#### 1.4 Sampling time to death ####
# based on the Dutch mortality tables
data_expanded <- data %>%
  dplyr::select(id, i_age_1, i_sex) %>% 
  uncount(60) %>%                             # Duplicate each ID 10 times ##PV: 60?
  group_by(id) %>%                            # Group by ID
  mutate(age = i_age_1 + row_number() - 1,
         sex = if_else(i_sex == "m", 0, 1)) %>% 
  ungroup() %>% 
  filter(age < 100)

# set.seed(123) 
data_expanded <- left_join(data_expanded, mci_death_probability, by = c("age" = "age", "sex" = "gender")) %>% 
  dplyr::select(id, i_age_1, age, sex, chance_death) %>% 
  mutate(chance = runif(nrow(data_expanded), min = 0, max = 1),
         death = if_else(chance_death > chance, 1, 0))

data_died <- group_by(data_expanded, id) %>% 
  filter(death == 1) %>% 
  slice(1) %>% ##extract first time someone has died
  ungroup()

data_died <- data_died %>% 
  mutate(time_mci_to_death = age - i_age_1 + 0.5 ##0.5 does the half-cycle correction
  ) %>% dplyr::select(id, time_mci_to_death)
#### 1.5 Phase 1 output ####
# Postprocessing states for a Markov trace
out_p1 <- left_join(pred_mci, data_died, by = "id") %>% 
  mutate(
    ##for some people death is not sampled before 100, for those people fix death time to be time between age at baseline and 100.
    time_mci_to_death = ifelse(is.na(time_mci_to_death)
                               , 100 - i_age_1
                               , time_mci_to_death))
##fixing dead time for those who died of an ARIA
if(sim_aria == "yes"){
  out_p1 <- out_p1 %>% 
    mutate(time_mci_to_death = ifelse(!is.na(t_dead_aria) & t_dead_aria < time_mci_to_death
                                      , t_dead_aria
                                      , time_mci_to_death))
}
out_p1 <- out_p1 %>% 
  mutate(
    died_in_mci = if_else(time_mci_to_dementia < time_mci_to_death, 0, 1) ##decide on outcome
    
    , time_in_mci = if_else(died_in_mci == 1, time_mci_to_death
                            , time_mci_to_dementia)
  ) 

##extracting side_effects in MCI
pred_mci_long <- out_p1 %>% dplyr::select(id, time_in_mci) %>% 
  merge(pred_mci_long, ., by = "id")
if(sim_aria == "yes"){
  mci_aria_count <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% ##select the first row after an additional aria
    dplyr::select(aria_severity, aria_symptoms) %>%
    table
  mci_aria_treat_stop <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_count == 2 | aria_severity == "severe") %>% nrow
  mci_aria_treat_stop_sev_aria <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_severity == "severe") %>% nrow
  mci_aria_treat_stop_sec_aria <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_count == 2) %>% nrow
  mci_aria_n_mri <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    mutate(mri_scheduled = ifelse(mri_scheduled == "yes", 1, 0)) %>% 
    pull(mri_scheduled) %>% sum(., na.rm = T)
  
  mci_aria_death <- out_p1 %>% 
    subset(time_in_mci == t_dead_aria) %>% nrow
  
  
  #output for cycle based data
  mci_aria_aggregated <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    mutate(aria_present = if_else(!is.na(aria_severity) | !is.na(aria_symptoms)
                                  , 1, 0)) %>% 
    group_by(fu_time_yrs, aria_severity, aria_symptoms) %>% 
    summarise(sum = sum(aria_present)) %>% 
    subset(!is.na(aria_severity))
  
  mci_mri_aggregated <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    mutate(mri_scheduled = ifelse(mri_scheduled == "yes", 1, 0)) %>% 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(mri_scheduled))
}

if(sim_aria == "yes" | sim_vol_discontinuation == "yes"){
  t_incr <- mean(diff(times))
  mci_cum_time_treated <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% pull(treated) %>% sum()
  mci_cum_time_treated <- mci_cum_time_treated * t_incr
  
  mci_treated_aggregated <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(treated))
}

if(treatment_scenario == "ttc" & treat_impl != "none"){
  mci_cum_time_treated <- pred_mci %>% pull(time_on_treatment) %>% sum
  
  ##need to alter the treatment variable to no longer have people be treated when they exceed their time on treatment
  mci_treated_aggregated <- pred_mci_long %>% subset(fu_time_yrs < time_in_mci) %>% 
    group_by(id) %>% 
    mutate(treated = if_else(time_on_treatment == lag(time_on_treatment, default = -1)
                             , 0, treated)) %>% 
    ungroup %>% 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(treated))
}

rm(pred_mci); rm(pred_mci_long); rm(mci_aria); rm(data_expanded)

#### 2. Phase 2 AD ####
#### 2.1 Inputs for the prediction function ####

##input data
input_phase2 <- out_p1 %>% subset(died_in_mci == 0) %>% 
  ##set-up the variables that were carried over for the new function
  mutate(i_living = ifelse(i_living != "zelfstandig met partner/gezin", 0, 1), 
         i_age_1 = i_age_1 + time_in_mci, ##increase age by time in MCI
         i_age_1_scaled = (i_age_1 - 64.85) / 7.5,
         diagnoseoms = 0, ##fix diagnosis at baseline to be MCI
  ) 

if(sim_aria == "yes"){
  input_phase2 <- input_phase2 %>% 
    ##setup treatment variable
    mutate(
      ##some people had aria during sampled conversion, set treatment to 1 if so - slightly underestimates ARIA duration but practical solution.
      ##also accounts for severe aria by keeping treated at 0
      treated = if_else(aria_severity %in% c("mild", "moderate") & aria_count < 2 & treated == 0
                        , 1
                        , treated
                        , treated)
    ) 
}

input_phase2 <- input_phase2 %>% 
  dplyr::select(id, time_in_mci, i_age_1, i_sex, i_age_1_scaled, i_living, diagnoseoms
                , any_of(c("pred_mmse", "treated", "aria_count", "time_on_treatment", "treat_all_or_nothing")))

input_phase2 <- input_phase2 %>% 
  rename(mmse_baseline = pred_mmse ##mmse at start of dementia
  ) 

## set timepoints
t_split <- 4 ##when the joint model transitions to the extension model
times <- seq(0, 30, length.out = 12 * 30 + 1)
# times[1] <- 1e-3 ##set the first time point of both the joint model and extension model to be just a little over zero for the b-spline matrix
# times[times == t_split] <- times[times == t_split] + times[1] ##make the first time after the split to line up with the first time

#### 2.2 Prediction function AD (requires vectorization) ####

#### 2.3 Predicting time to institutionalization  ####
input_phase2 <- dementia_draw_random_effects(input_phase2, joint_model_dem
                                             , from_mci = "yes")

if(sim_aria == "yes"){
  dem_aria <- aria_side_effects(data = input_phase2
                                , aria_prob_mat = aria_prob
                                , times = times
                                , from_mci = "yes"
                                , aria_discount = aria_discount
                                , aria_discount_delay = aria_discount_delay
                                , length_aria = aria_duration
                                , aria_all_observed = aria_all_observed, aria_visitation_scheme= aria_visitation_scheme
                                , treatment_scenario = treatment_scenario, time_to_clear = time_to_clear)
  
  ##clean out the now-outdated treatment and aria information
  input_phase2 <- input_phase2 %>% dplyr::select(-any_of(c("treated", "aria_count", "time_on_treatment")))
}

if(model_approach == "jm"){
  pred_inst <- prediction_dementia(input_phase2,                                     
                                   joint_model_dem,
                                   times = times, 
                                   slowing = slowing,
                                   stop_mmse = stop_mmse,
                                   t_split = t_split, # = 4; years after which the model is split? ## yeah, timepoint at which the years are split
                                   id = "id",                                       
                                   ext_model = ext_model,                               
                                   pred_part = "inst"
                                   , treat_impl = treat_impl
                                   , stop_time = stop_time
                                   , red_haz = red_haz
                                   , red_haz_perc = red_haz_perc
                                   , from_mci = "yes"
                                   , waning = waning
                                   , side_effect = sim_aria, side_effect_data = dem_aria
                                   , treat_heterogeneity = treat_heterogeneity
  )
  
  ## need the mmse values to calculate the time in dementia stages, so retaining the long formatted data
  pred_inst_long <- pred_inst
}

if(model_approach == "weibull"){
  pred_inst <- predict_weibull_time(
    input_phase2
    , model = dem_hazard_model
    , joint_model = joint_model_dem
    , times = times, 
    slowing = slowing,
    stop_mmse = stop_mmse,
    id = "id",                                       
    pred_part = "inst"
    , treat_impl = treat_impl
    , stop_time = stop_time
    , red_haz = red_haz
    , red_haz_perc = red_haz_perc
    , from_mci = "yes"
    , dementia_sim = "yes"
    , waning = waning
    , side_effect = sim_aria, side_effect_data = dem_aria
    , treat_heterogeneity = treat_heterogeneity
  )
  
  pred_inst_long <- pred_inst
}

##sampling survival times
pred_inst <- pred_inst %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ungroup 

#### 2.4 Predicting time to death in the community  ####
if(model_approach == "jm"){
  pred_dead <- prediction_dementia(input_phase2,                                     
                                   joint_model_dem,  
                                   times = times, 
                                   slowing = slowing, ##at a slowing of 1 there is no progression.
                                   stop_mmse = stop_mmse,
                                   t_split = t_split, 
                                   id = "id",                                       
                                   ext_model = ext_model,       
                                   pred_part = "dead"
                                   , treat_impl = treat_impl
                                   , stop_time = stop_time
                                   , red_haz = red_haz
                                   , red_haz_perc = red_haz_perc
                                   , from_mci = "yes"
                                   , side_effect = sim_aria, side_effect_data = dem_aria
                                   , waning = waning
                                   , treat_heterogeneity = treat_heterogeneity
  )
}

if(model_approach == "weibull"){
  pred_dead <- predict_weibull_time(
    input_phase2
    , model = dem_hazard_model
    , joint_model = joint_model_dem
    , times = times, 
    slowing = slowing,
    stop_mmse = stop_mmse,
    id = "id",                                       
    pred_part = "dead"
    , treat_impl = treat_impl
    , stop_time = stop_time
    , red_haz = red_haz
    , red_haz_perc = red_haz_perc
    , from_mci = "yes"
    , dementia_sim = "yes"
    , waning = waning
    , side_effect = sim_aria, side_effect_data = dem_aria
    , treat_heterogeneity = treat_heterogeneity
  )
}


# pred_mmse_dead <- pred_dead

##sampling survival times
pred_dead <- pred_dead %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ##change fu_time_yrs to aria time if it occured before death time
  ungroup


if(sim_aria == "yes"){
  pred_dead <- pred_dead %>% 
    mutate(fu_time_yrs = ifelse(!is.na(t_dead_aria) & t_dead_aria < fu_time_yrs
                                , t_dead_aria
                                , fu_time_yrs)
    )
}

#### 2.5 Phase 2 output ####
pred_dead <- mutate(pred_dead, ttdeath = fu_time_yrs) %>%     
  dplyr::select(id, ttdeath)

pred_inst <- mutate(pred_inst, ttinst = fu_time_yrs) %>% 
  dplyr::select(-fu_time_yrs, -surv_prob, -any_of("pred_mmse"), -haz)

out_p2 <- full_join(pred_dead, pred_inst, by = c("id")) %>% 
  mutate(institutionalized = if_else(ttinst < ttdeath, 1, 0)
         , time_in_dementia = ifelse(institutionalized == 1, ttinst, ttdeath)) 

t_incr <- mean(diff(times)) ## average length of an increment of time

pred_dementia_stages <- pred_inst_long %>% 
  group_by(id) %>% 
  summarise(time_mild_dem = sum(pred_mmse > 20) * t_incr
            , time_mod_dem = sum(pred_mmse <= 20 & pred_mmse >= 10) * t_incr
            , time_sev_dem = sum(pred_mmse < 10) * t_incr
  )

out_p2 <- merge(out_p2, pred_dementia_stages, by = "id")
##fix the dementia stages based on MMSE to conform to the dementia length
out_p2 <- out_p2 %>% 
  mutate(
    ##if total time in dementia is dementia is shorter than time in mild dementia based on MMSe, time in mild dementia is set to total time in dementia
    time_mild_dem = ifelse(time_mild_dem > time_in_dementia
                           , time_in_dementia
                           , time_mild_dem)
    ##if people transition out of dementia during moderate dementia, their mild dementia time is equal to total dementia time minus mild dementia time
    , time_mod_dem = ifelse((time_mild_dem + time_mod_dem) > time_in_dementia
                            , time_in_dementia - time_mild_dem
                            , time_mod_dem)
    ##if people transition out of dementia during severe dementia, their svere dementia time is equal to total dementia time minus mild and moderate dementia time
    , time_sev_dem = ifelse((time_mild_dem + time_mod_dem + time_sev_dem) > time_in_dementia
                            , time_in_dementia - (time_mild_dem + time_mod_dem)
                            , time_sev_dem)
    
    ##fix so times cannot be negative
    , time_mod_dem = ifelse(time_mod_dem < 0, 0, time_mod_dem)
    , time_sev_dem = ifelse(time_sev_dem < 0, 0, time_sev_dem)
  )

##aria count in dementia
pred_inst_long <- out_p2 %>% dplyr::select(id, time_in_dementia) %>% 
  merge(pred_inst_long, ., by = "id")
pred_inst_long <- out_p1 %>% dplyr::select(id, time_in_mci) %>% 
  merge(pred_inst_long, ., by = "id")

if(sim_aria == "yes"){
  pred_inst_long <- pred_inst_long  %>%
    ##editing side-effects to stop after the treatment would have stopped
    mutate(treated = ifelse(pred_mmse <= stop_mmse, 0, treated)
           , aria_severity = ifelse(pred_mmse <= stop_mmse, NA, aria_severity)
           , aria_symptoms = ifelse(pred_mmse <= stop_mmse, NA, aria_symptoms)
    )
  
  dem_aria_count <- pred_inst_long %>% 
    subset(fu_time_yrs < time_in_dementia) %>% ##before people convert and after 2 aria people stop
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% ##select the first row after an additional aria
    dplyr::select(aria_severity, aria_symptoms) %>%
    table
  dem_aria_treat_stop <- pred_inst_long %>% 
    subset(fu_time_yrs < time_in_dementia & aria_count <= 2) %>% ##before people convert and after 2 aria people stop
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_count == 2 | aria_severity == "severe") %>% nrow
  dem_aria_treat_stop_sev_aria <- pred_inst_long %>% 
    subset(fu_time_yrs < time_in_dementia) %>% ##before people convert and after 2 aria people stop
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_severity == "severe") %>% nrow
  dem_aria_treat_stop_sec_aria <- pred_inst_long %>% 
    subset(fu_time_yrs < time_in_dementia & aria_count <= 2) %>% ##before people convert and after 2 aria people stop
    dplyr::select(aria_severity, aria_symptoms, aria_count, id) %>%
    group_by(id) %>% filter(aria_count != lag(aria_count)) %>% ungroup %>% 
    subset(aria_count == 2) %>% nrow
  dem_aria_n_mri <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% 
    mutate(mri_scheduled = ifelse(mri_scheduled == "yes", 1, 0)) %>% 
    pull(mri_scheduled) %>% sum(., na.rm = T)
  
  dem_aria_death <- out_p2 %>% 
    subset(time_in_dementia == t_dead_aria) %>% nrow
  
  #output for cycle based data
  dem_aria_aggregated <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% 
    mutate(aria_present = if_else(!is.na(aria_severity) | !is.na(aria_symptoms)
                                  , 1, 0)
           , fu_time_yrs = fu_time_yrs + time_in_mci) %>%
    group_by(fu_time_yrs, aria_severity, aria_symptoms) %>% 
    summarise(sum = sum(aria_present)) %>% 
    subset(!is.na(aria_severity))
  
  dem_mri_aggregated <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% 
    mutate(mri_scheduled = ifelse(mri_scheduled == "yes", 1, 0)
           , fu_time_yrs = fu_time_yrs + time_in_mci) %>% 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(mri_scheduled))
}

if(sim_aria == "yes" | sim_vol_discontinuation == "yes"){
  pred_inst_long <- pred_inst_long  %>%
    ##editing side-effects to stop after the treatment would have stopped
    mutate(treated = ifelse(pred_mmse <= stop_mmse, 0, treated)
    )
  t_incr <- mean(diff(times))
  dem_cum_time_treated <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% pull(treated) %>% sum()
  dem_cum_time_treated <- dem_cum_time_treated * t_incr
  
  dem_treated_aggregated <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% 
    mutate(fu_time_yrs = round(fu_time_yrs + time_in_mci, 4)) %>% ##rounding because otherwise it doesn't line up the fu moments 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(treated))
}

if(treatment_scenario == "ttc" & treat_impl != "none"){
  dem_cum_time_treated <- out_p2 %>% pull(time_on_treatment) %>% sum
  
  ##need to alter the treatment variable to no longer have people be treated when they exceed their time on treatment
  dem_treated_aggregated <- pred_inst_long %>% subset(fu_time_yrs < time_in_dementia) %>% 
    group_by(id) %>% 
    mutate(treated = if_else(time_on_treatment == lag(time_on_treatment, default = time_to_clear)
                             , 0, treated)) %>% 
    ungroup %>% 
    mutate(fu_time_yrs = round(fu_time_yrs + time_in_mci, 4)) %>% ##rounding because otherwise it doesn't line up the fu moments 
    group_by(fu_time_yrs) %>% 
    summarise(sum = sum(treated))
}

rm(pred_inst_long); rm(dem_aria)

#### 3. Phase 3 Death in the institution ####
#### 3.1 Inputs for the prediction function ####
# data
input_phase3 <- out_p2 %>% subset(institutionalized == 1) %>%
  dplyr::select(id, i_age_1, i_living, i_sex, ttinst) %>% 
  mutate(age_update = floor(i_age_1 + ttinst))

#### 3.2 Prediction function AD  

#### 3.3 Predicting time to death in the institution ####
pred_inst_mort <- prediction_institution(data = input_phase3, model = inst_mort
                                         , times = seq(0, 30, length.out = 12 * 30 + 1)
                                         , id = "id")

pred_inst_dead <- pred_inst_mort %>% group_by(id) %>%
  slice(which.min(abs(surv_prob - runif(1)))) %>%
  ungroup() %>%
  mutate(ttdeath_inst = fu_time_yrs
         , age_at_end_fu = age_update + fu_time_yrs
  ) %>% 
  dplyr::select(id, ttdeath_inst) %>% rename(time_in_inst = ttdeath_inst)

rm(pred_inst_mort)

#### 4. Postprocessing ####

#### 4.1 Preparing dataset with all the stage times for everyone
dt_stage_times <- out_p2 %>% 
  dplyr::select(id, time_in_dementia, any_of(c("time_mild_dem", "time_mod_dem", "time_sev_dem"))
                , institutionalized) %>% 
  merge(out_p1, ., by = "id", all = T)
dt_stage_times <- pred_inst_dead %>% 
  merge(dt_stage_times, ., by = "id", all = T)

dt_stage_times <- dt_stage_times %>% 
  dplyr::select(id, died_in_mci, institutionalized, time_in_mci, time_in_dementia
                , any_of(c("time_mild_dem", "time_mod_dem", "time_sev_dem")), time_in_inst)

##formatting in case of modelled as hazard
# if(model_approach == "weibull"){
#   dt_stage_times <- dt_stage_times %>% 
#     mutate(time_mild_dem = time_in_dementia, time_mod_dem = NA, time_sev_dem = NA)
# }

##all NA's indicate never reached a stage or spent 0 time there
dt_stage_times <- dt_stage_times %>% 
  mutate_all(., function(x) ifelse(is.na(x), 0, x))

#### 4.1 formatting ARIA side-effects ##
if(sim_aria == "yes"){ 
  t_aria <- mci_aria_count + dem_aria_count
  temp_names <- data.frame(t_aria)
  
  t_aria_mci <- mci_aria_count %>% matrix(nrow = 1) %>% data.frame
  names(t_aria_mci) <- paste0("aria_", temp_names$aria_severity, "_", temp_names$aria_symptoms)
  
  t_aria_dem <- dem_aria_count %>% matrix(nrow = 1) %>% data.frame
  names(t_aria_dem) <- paste0("aria_", temp_names$aria_severity, "_", temp_names$aria_symptoms)
  
  # mutate(aria_symptoms = ifelse(aria_symptoms == 0, "asymptomatic", "symptomatic"))
  t_aria <- t_aria %>% matrix(nrow = 1) %>% data.frame
  
  names(t_aria) <- paste0("aria_", temp_names$aria_severity, "_", temp_names$aria_symptoms)
  
  n_aria_mri <- mci_aria_n_mri + dem_aria_n_mri
  if(aria_all_observed == "yes"){n_aria_mri <- NA} ## counting MRI is meaningless if you assume all is observed
  
  aria_death <- mci_aria_death + dem_aria_death
} 

if(sim_aria == "yes" | sim_vol_discontinuation == "yes"){
  t_time_treated <- mci_cum_time_treated + dem_cum_time_treated
}


#### 4.2 Prepare cycle based data for output used in plots & CEA
## turn person by person stage times into number of people per cycle
expand_trajectory <- function(df) {
  df %>%
    rowwise() %>%
    mutate(
      years = list(0.5:ceiling(sum(c_across(starts_with("time_"))))) ## half-cycle correction
    ) %>%
    unnest(years) %>%
    mutate(
      stage = case_when(
        years <= time_in_mci ~ "community_mci",
        years <= time_in_mci + time_mild_dem ~ "community_mild",
        years <= time_in_mci + time_mild_dem + time_mod_dem ~ "community_moderate",
        years <= time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem ~ "community_severe",
        years <= time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem + time_in_inst ~ "institutionalization",
        years > time_in_mci + time_mild_dem + time_mod_dem + time_sev_dem + time_in_inst ~ "death"
      )
    ) %>%
    group_by(years, stage) %>%
    summarise(count = n(), .groups = "drop") %>%
    mutate(years = years - 0.5) %>% 
    pivot_wider(names_from = stage, values_from = count, values_fill = 0)
}

# Apply function
cycle_based_data <- expand_trajectory(dt_stage_times)

##need to fix death counting in post
cycle_based_data <- cycle_based_data %>% 
  mutate(death = nrow(data) - community_mci - community_mild - 
           community_moderate - community_severe - institutionalization)

##order of cycle columns can change, so fixing it
cycle_based_data <- cycle_based_data %>% 
  dplyr::select(years, community_mci, community_mild, community_moderate
                , community_severe, institutionalization, death)

##Format treatment to be added to cycle based data
if(sim_aria == "yes" | sim_vol_discontinuation == "yes" | (treatment_scenario == "ttc" & treat_impl != "none")) {
  target_times <- 1:max(cycle_based_data$years + 1) 
  
  mci_treated_aggregated <- mci_treated_aggregated %>% rename(treated_mci = sum)
  mci_treated_aggregated <-  mci_treated_aggregated %>% 
    mutate(years = sapply(fu_time_yrs, function(x) min(target_times[target_times > x], na.rm = TRUE))) ##selected closests time for each fu_time_yrs
  mci_treated_aggregated <- mci_treated_aggregated %>% group_by(years) %>% 
    summarise(treated_mci = mean(treated_mci)) %>% mutate(years = years - 1) ##calculate mean amount of people being treated within each bracked
  
  dem_treated_aggregated <- dem_treated_aggregated %>% rename(treated_dem = sum)
  dem_treated_aggregated <-  dem_treated_aggregated %>% 
    mutate(years = sapply(fu_time_yrs, function(x) min(target_times[target_times > x], na.rm = TRUE))) ##selected closests time for each fu_time_yrs
  dem_treated_aggregated <- dem_treated_aggregated %>% group_by(years) %>% 
    summarise(treated_dem = mean(treated_dem)) %>% mutate(years = years - 1) ##calculate mean amount of people being treated within each bracked
  
  cycle_based_data <- merge(cycle_based_data, mci_treated_aggregated, all = T) %>% 
    merge(., dem_treated_aggregated, all = T, by = "years") 
}

##format side-effects to be added to cycle based data
if(sim_aria == "yes"){
  mci_aria_aggregated$stage <- "mci"
  dem_aria_aggregated$stage <- "dem"
  
  aria_aggregated <- bind_rows(mci_aria_aggregated, dem_aria_aggregated)
  
  aria_aggregated <-  aria_aggregated %>% 
    mutate(
      sum = ifelse(is.na(sum), 0, sum)) %>% 
    mutate(years = sapply(fu_time_yrs, function(x) min(target_times[target_times > x], na.rm = TRUE)))
  
  aria_aggregated <- aria_aggregated %>% 
    ##calculate mean aria per category over the specified timebracked
    group_by(years, aria_severity, aria_symptoms, stage) %>%
    summarise(mean_count = mean(sum, na.rm = TRUE), .groups = "drop") %>%
    mutate(category = paste("aria", aria_severity, aria_symptoms, stage, sep = "_")) %>%
    ##turn the long form database into a wide database which can be added to the other cycle data
    dplyr::select(years, category, mean_count) %>%
    pivot_wider(names_from = category, values_from = mean_count, values_fill = 0) %>% 
    mutate(years = years - 1)
  
  cycle_based_data <- merge(cycle_based_data, aria_aggregated, all= T)
}

##adding the number of MRIs
if(sim_aria == "yes"){
  mci_mri_aggregated <- mci_mri_aggregated %>% 
    rename(mci_mri = sum) %>% 
    mutate(mci_mri = ifelse(is.na(mci_mri), 0 , mci_mri))
  mci_mri_aggregated <-  mci_mri_aggregated %>% 
    mutate(years = sapply(fu_time_yrs, function(x) min(target_times[target_times > x], na.rm = TRUE))) ##selected closests time for each fu_time_yrs
  mci_mri_aggregated <- mci_mri_aggregated %>% group_by(years) %>% 
    summarise(n_mri_mci = sum(mci_mri)) %>% mutate(years = years - 1) ##calculate total MRIs within each bracket
  
  dem_mri_aggregated <- dem_mri_aggregated %>% 
    rename(dem_mri = sum) %>% 
    mutate(dem_mri = ifelse(is.na(dem_mri), 0 , dem_mri))
  dem_mri_aggregated <-  dem_mri_aggregated %>% 
    mutate(years = sapply(fu_time_yrs, function(x) min(target_times[target_times > x], na.rm = TRUE))) ##selected closests time for each fu_time_yrs
  dem_mri_aggregated <- dem_mri_aggregated %>% group_by(years) %>% 
    summarise(n_mri_dem = sum(dem_mri)) %>% mutate(years = years - 1) ##calculate total MRIs within each bracket
  
  cycle_based_data <- merge(cycle_based_data, mci_mri_aggregated, all = T) %>% 
    merge(., dem_mri_aggregated, all = T)
}

#### 4.3 Summary statistics of mean time and when people died
summary_output_sim <- dt_stage_times %>% 
  summarise(t_mci = mean(time_in_mci)
            , t_mild = mean(time_mild_dem)
            , t_moderate = mean(time_mod_dem)
            , t_severe = mean(time_sev_dem)
            , t_inst = mean(time_in_inst)
            , start_n = nrow(data)
            , dead_mci = sum(died_in_mci)
            , dead_dem_com = nrow(data) - dead_mci - sum(institutionalized))

#### 4.4 Outputting simulation results ####

#### summary statistics
this_sim <- this_sim %>% 
  mutate(t_mci = summary_output_sim$t_mci
         , t_mild = summary_output_sim$t_mild 
         , t_moderate = summary_output_sim$t_moderate
         , t_severe = summary_output_sim$t_severe
         , t_inst = summary_output_sim$t_inst
         , start_n = nrow(data)
         , dead_mci = summary_output_sim$dead_mci
         , dead_dem_com = summary_output_sim$dead_dem_com)

if(sim_aria == "yes"){
  this_sim <- this_sim %>% 
    
    mutate(aria_mild_asymptomatic_mci = t_aria_mci$aria_mild_asymptomatic
           , aria_moderate_asymptomatic_mci = t_aria_mci$aria_moderate_asymptomatic
           , aria_severe_asymptomatic_mci = t_aria_mci$aria_severe_asymptomatic
           , aria_mild_symptomatic_mci = t_aria_mci$aria_mild_symptomatic
           , aria_moderate_symptomatic_mci = t_aria_mci$aria_moderate_symptomatic
           , aria_severe_symptomatic_mci = t_aria_mci$aria_severe_symptomatic
           , aria_n_mri_mci = !!mci_aria_n_mri
           , aria_death_mci = !!mci_aria_death) %>% 
    
    mutate(aria_mild_asymptomatic_dem = t_aria_dem$aria_mild_asymptomatic
           , aria_moderate_asymptomatic_dem = t_aria_dem$aria_moderate_asymptomatic
           , aria_severe_asymptomatic_dem = t_aria_dem$aria_severe_asymptomatic
           , aria_mild_symptomatic_dem = t_aria_dem$aria_mild_symptomatic
           , aria_moderate_symptomatic_dem = t_aria_dem$aria_moderate_symptomatic
           , aria_severe_symptomatic_dem = t_aria_dem$aria_severe_symptomatic
           , aria_n_mri_dem = !!dem_aria_n_mri
           , aria_death_dem = !!dem_aria_death)
}

if(sim_aria == "yes" | sim_vol_discontinuation == "yes"){
  this_sim <- this_sim %>% 
    mutate(t_treated_mci = !!mci_cum_time_treated
           , t_treated_dem = !!dem_cum_time_treated)
}

present_sim_results <- read.csv(here("Simulation Output", "results sim.csv"))

sim_results <- bind_rows(present_sim_results, this_sim)

write.csv(sim_results, here("Simulation Output", "results sim.csv"), row.names = F)

#### cycle data for plotting and CEA
sim_characters <- this_sim[,1:(which(names(this_sim) == "t_mci")-1)]
export_wide <- cbind(sim_characters, cycle_based_data)

file_name <- paste0("temp_cycle_sim_", this_sim$sim_num, ".csv")
write.csv(export_wide, here("simulation Output/Temporary files", file_name), row.names = F)


