## Contains all the functions used on the "Microsimulation_25_04_17_pv.R" Function

#### calculate baseline MMSE in dementia
grouper_dem_baseline <- function(data, joint_model){
  betas_fixed <- joint_model$lmm$betas_fixed
  form_beta_fixed <- joint_model$lmm$form_beta_fixed 
  # form_beta_fixed <- as.formula(paste0(" ~", as.character(form_beta_fixed)))
  
  data$fu_time_yrs <- 0
  
  mm_beta  <- model.matrix(formula(form_beta_fixed), data = data)
  
  data$mmse_baseline <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
    data$re_int
  data %>% dplyr::select(id, mmse_baseline) %>% return
}

#### decline speed stratifier function that calculates decline speed by individual if stratification decline speed needs to be done ####
## takes in data prior to the MCI stage

grouper_decline_speed <- function(data){
  betas_fixed <- mci_jm_lmm_fixed$est[str_detect(mci_jm_lmm_fixed$var, "fu_time_yrs")]  
  form_beta_fixed <- mci_specs$form_beta_fixed %>% str_replace(., "\\*", "\\:")
  form_beta_fixed <- paste0(" ~", form_beta_fixed)
  
  data$fu_time_yrs <- 1
  
  mm_beta  <- model.matrix(formula(form_beta_fixed), data = data)[,-1]
  
  data$slope <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
    data$re_slope * data$fu_time_yrs
  data %>% dplyr::select(id, slope) %>% return
}

#### Parametric senstivity analysis functions ####
## two seperate functions for the mci and dementia joint models. Takes the joint model objects and the vcov
coef_sampler_joint_model_mci <- function(joint_model, vcov){
  coefs <- c(
    joint_model$lmm$betas_fixed ## lmm betas
    , NA ## lmm sigma (residuals)
    , joint_model$tte$gammas ## tte gamma
    , joint_model$tte$alphas ## tte alpha
    , joint_model$tte$gammas_bs ## tte gamma_bs
    , joint_model$re)
  
  coefs <- coefs %>% unlist
  
  names(coefs) <- 
    c(rep("lmm", times = length(joint_model$lmm$betas_fixed))
      , "sigma"
      , rep("gammas", times = length(joint_model$tte$gammas))
      , rep("alphas", times = length(joint_model$tte$alphas))
      , rep("gammas_bs", times = length(joint_model$tte$gammas_bs))
      , names(joint_model$re)
    )
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  output_joint_model <- joint_model
  output_joint_model$lmm$betas_fixed <- sampled_coefs[names(sampled_coefs) == "lmm"]
  output_joint_model$tte$gammas_bs <- sampled_coefs[names(sampled_coefs) == "gammas_bs"]
  output_joint_model$tte$gammas <- sampled_coefs[names(sampled_coefs) == "gammas"]
  output_joint_model$tte$alphas <- sampled_coefs[names(sampled_coefs) == "alphas"]
  output_joint_model$re$int_var <- sampled_coefs[names(sampled_coefs)  == "int_var"]
  output_joint_model$re$slope_var <- sampled_coefs[names(sampled_coefs) == "slope_var"]
  output_joint_model$re$cov <- sampled_coefs[names(sampled_coefs) ==  "cov"]
  
  return(output_joint_model)
}

coef_sampler_joint_model_dem <- function(joint_model, vcov){
  coefs <- c(
    joint_model$lmm$betas_fixed ## lmm betas
    , NA ## lmm sigma (residuals)
    , joint_model$tte$gammas ## tte gamma
    , joint_model$tte$alphas ## tte alpha
    , joint_model$tte$gammas_bs_dead ## tte gamma_bs dead
    , joint_model$tte$gammas_bs_inst ## tte gamma_bs inst
    , joint_model$re)
  
  coefs <- coefs %>% unlist
  
  names(coefs) <- 
    c(rep("lmm", times = length(joint_model$lmm$betas_fixed))
      , "sigma"
      , rep("gammas", times = length(joint_model$tte$gammas))
      , rep("alphas", times = length(joint_model$tte$alphas))
      , rep("gammas_bs_dead", times = length(joint_model$tte$gammas_bs_dead))
      , rep("gammas_bs_inst", times = length(joint_model$tte$gammas_bs_inst))
      , names(joint_model$re)
    )
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  output_joint_model <- joint_model
  output_joint_model$lmm$betas_fixed <- sampled_coefs[names(sampled_coefs) == "lmm"]
  output_joint_model$tte$gammas_bs_dead <- sampled_coefs[names(sampled_coefs) == "gammas_bs_dead"]
  output_joint_model$tte$gammas_bs_inst <- sampled_coefs[names(sampled_coefs) == "gammas_bs_inst"]
  output_joint_model$tte$gammas <- sampled_coefs[names(sampled_coefs) == "gammas"]
  output_joint_model$tte$alphas <- sampled_coefs[names(sampled_coefs) == "alphas"]
  output_joint_model$re$re_int <- sampled_coefs[names(sampled_coefs)  == "re_int"]
  output_joint_model$re$re_slope <- sampled_coefs[names(sampled_coefs) == "re_slope"]
  output_joint_model$re$re_cov <- sampled_coefs[names(sampled_coefs) ==  "re_cov"]
  
  return(output_joint_model)
}

## function for the weibull extension model. Takes the model object and the vcov
coef_sampler_weibull_models <- function(model, vcov){
  coefs <- model$coef
  
  sampled_coefs <- mvrnorm(n = 1, mu = coefs, Sigma = vcov)
  
  model$coef <- sampled_coefs
  
  return(model)
}  

#### Voluntary treatment discontinuation ####

##takes the data argument prior to mci
## discount_prob - likelihood per year to stop treatment
## treatment_scenario - continuous or ttc
## time_to_clear - in case of ttc sampled voluntary treatment stopping after clearing time are taken out

vol_treat_disc <- function(data, discount_prob, treatment_scenario = "continuous", time_to_clear = NA){
  data$t_discontinue <- rexp(nrow(data), rate = discount_prob)
  if(treatment_scenario == "ttc"){
    data$t_discontinue[data$t_discontinue > time_to_clear] <- NA
  }
  return(data)
}

#### ARIA sampler ####

## Data - the data file of mci or dementia patients
## aria_prob_mat - matrix that specifies the probability of mild, moderate, severe aria and their likelihood to be symptomatic and deadly in case of symptomatic aria
## aria_discount - how much the probability of aria decreased after aria_discount_delay (yrs)
## aria_all_observed - if all asymptomatic aria's are presumed to be know
## aria_visitation_scheme - time points (yrs) which MRIs are scheduled for monitoring
## sim_vol_discontinuation - if voluntary discontinuation is used, this is applied here in the function to alter the treatment status and thus stop ARIAs from occuring
## treatment_scenario - continuous or ttc scenario 
## time_to_clear - in case of ttc scenario people are presumed to clear after this time (yrs) on treatment and no more ARIA occur

aria_side_effects <- function(data, aria_prob_mat, times, from_mci = "no"
                              , aria_discount = aria_discount
                              , length_aria = aria_duration, aria_discount_delay = aria_discount_delay
                              , aria_all_observed = "no", aria_visitation_scheme
                              , sim_vol_discontinuation = "no"
                              , treatment_scenario = "continuous", time_to_clear = NA){
  # aria_discount <- 0; length_aria <- 3/12; data <- data; aria_prob_mat <- aria_prob; aria_discount_delay <- aria_discount_delay; from_mci <- "no"; aria_all_observed <- "no"; aria_visitation_scheme <- aria_visitation_scheme; treatment_scenario = "ttc"; time_to_clear = 1.5; from_mci = "no"
  
  long_data <- data[rep(row.names(data), each = length(times)),]
  long_data$fu_time_yrs <- rep_len(times, length.out = nrow(long_data)) 
  
  if(from_mci == "no"){
    long_data <- long_data %>% mutate(prior_aria_count = 0
                                      , prior_treatment_time = 0)
  }
  
  if(from_mci == "yes"){
    long_data <- long_data %>% mutate(prior_aria_count = aria_count
                                      , aria_count = 0)
    
    if(treatment_scenario == "ttc"){
      long_data <- long_data %>% mutate(
        prior_treatment_time = time_on_treatment
        , time_on_treatment = 0)}
  }
  
  ## reducing dataframe 
  long_data <- long_data %>% dplyr::select(any_of(c("id", "fu_time_yrs", "prior_aria_count", "time_in_mci", "treated", "t_discontinue", "prior_treatment_time")))
  
  ##if starting in MCI or dementia, the mri schedule can be applied the same for all participants
  if(from_mci == "no"){
    ##select closests times to aria visitation scheme
    times_at_mri <- sapply(aria_visitation_scheme, function(t){
      closest_interval <- min(times[times >= t], na.rm = T)
    })
    long_data$mri_scheduled <- "no"
    long_data$mri_scheduled[long_data$fu_time_yrs %in% times_at_mri] <- "yes" 
  }
  
  ##if transfering in from dementia, the mri schedule needs to be adjusted for the participants based on the time they already spend in the MCI stage
  if(from_mci == "yes"){
    long_data$mri_scheduled <- "no"
    
    long_data <- long_data %>% 
      group_by(id) %>% 
      mutate(
        adjusted_times = fu_time_yrs + time_in_mci  # Apply individual-specific offset,
        , times_at_mri = 
          ifelse(time_in_mci < max(aria_visitation_scheme) ##check people spend time in dementia during the vistation stage
                 , list(sapply(aria_visitation_scheme, function(t) { ##creates a list of time-increments in dementia which match the total time from the start of the simulation
                   min(fu_time_yrs[adjusted_times >= t], na.rm = TRUE)
                 }))
                 , list(NA))
      ) %>% 
      mutate(mri_scheduled = ifelse(fu_time_yrs %in% unlist(times_at_mri), "yes", mri_scheduled)) %>%
      ungroup %>% 
      dplyr::select(-times_at_mri, -adjusted_times)
  }
  
  ##size side-effects to conform to the time-increment used
  time_increments <- mean(diff(times))
  aria_prob_mat$probability_occurence <- aria_prob_mat$probability_occurence * time_increments
  
  ##determine number of cycles over which aria's occur
  length_aria <- round(length_aria/time_increments)
  
  ##severity distribution
  aria_prob_mat$probability_occurence[aria_prob_mat$severity != "total"] <- 
    aria_prob_mat$probability_occurence[aria_prob_mat$severity != "total"] / 
    sum(aria_prob_mat$probability_occurence[aria_prob_mat$severity != "total"])
  
  ##determine to carry over treatment indicator or create new one
  if(from_mci == "no"){
    long_data$treated <- 1
  }
  
  ##apply voluntary treatment discontinuation
  if(sim_vol_discontinuation == "yes"){
    if(from_mci == "no"){
      long_data$treated[long_data$fu_time_yrs > long_data$t_discontinue] <- 0
    }
    if(from_mci == "yes"){
      long_data$treated[(long_data$fu_time_yrs - long_data$time_in_mci) > long_data$t_discontinue] <- 0
    }
  }
  
  long_data$side_effect_probability <- aria_prob_mat$probability_occurence[aria_prob_mat$severity == "total"]
  
  ##Discount the rate at which aria occurs - with an offset 
  if(aria_discount != 0){
    
    if(from_mci == "no"){
      ##create indicator of discounting 
      apply_discount <- long_data$fu_time_yrs >= aria_discount_delay
      
      ##discount after the indicated delay with an applied offset
      long_data$side_effect_probability[apply_discount] <- 
        long_data$side_effect_probability[apply_discount] * 
        (1 - aria_discount) ^ (long_data$fu_time_yrs[apply_discount] - aria_discount_delay)
      
    }else{
      ##for transitions from mci to dementia earlier time on treatment needs to be accounted for
      apply_discount <- (long_data$fu_time_yrs + long_data$time_in_mci) >= aria_discount_delay
      
      long_data$side_effect_probability[apply_discount] <- 
        long_data$side_effect_probability[apply_discount] * 
        (1 - aria_discount) ^ ((long_data$fu_time_yrs + long_data$time_in_mci)[apply_discount] - aria_discount_delay)
      
    }
    
  }
  
  ##sample side-effects for people on treatment, based on how long they have been in treatment for
  long_data$aria_occurence <- 0
  long_data$aria_occurence[long_data$treated == 1] <- 
    rbinom(sum(long_data$treated == 1), 1, long_data$side_effect_probability[long_data$treated == 1])
  
  ##sample severity of side-effect if they occured
  long_data$aria_severity <- NA
  long_data$aria_severity[long_data$aria_occurence == 1] <- 
    sample(c("mild", "moderate", "severe"), sum(long_data$aria_occurence == 1)
           , prob = aria_prob_mat$probability_occurence[aria_prob_mat$severity != "total"]
           , replace = T)
  
  ##sample whether or not side-effects also produced symptoms
  long_data$aria_symptoms <- NA
  long_data$aria_symptoms[long_data$aria_occurence == 1] <-
    rbinom(sum(long_data$aria_occurence == 1), 1 
           , prob = aria_prob_mat$probability_symptoms[1])
  
  ##sample whether severe symptomatic aria was deadly
  long_data$aria_deadly <- NA
  long_data$aria_deadly[long_data$aria_severity == "severe" & long_data$aria_symptoms == 1 & long_data$aria_occurence == 1] <- 
    rbinom(sum(long_data$aria_severity == "severe" & long_data$aria_symptoms == 1 & long_data$aria_occurence == 1), 1 
           , prob = aria_prob_mat$probability_symptoms_deadly[aria_prob_mat$severity == "severe"])
  
  ##set everything to zero after deadly side_effect
  long_data <- long_data %>% 
    group_by(id) %>% 
    mutate(t_dead_aria = min(fu_time_yrs[aria_deadly == 1], na.rm = T)
           , aria_occurence = if_else(fu_time_yrs > t_dead_aria
                                      , 0
                                      , aria_occurence, aria_occurence)
           
           , aria_symptoms = if_else(fu_time_yrs > t_dead_aria
                                     , NA
                                     , aria_symptoms, aria_symptoms)
           
           , aria_severity = if_else(fu_time_yrs > t_dead_aria
                                     , NA
                                     , aria_severity, aria_severity)) %>% 
    ungroup
  
  ##replicate side-effect values length_aria months forward
  long_data <- long_data %>% 
    group_by(id) %>% 
    mutate(
      ##determine closest aria time
      aria_time = ifelse(aria_occurence == 1, fu_time_yrs, NA)
      , closests_past_aria = cummax(replace(aria_time, is.na(aria_time), -Inf))
      , closests_aria_index = match(closests_past_aria, fu_time_yrs) ##for selecting symptoms and severity at these timepoints
      
      , aria_occurence = ifelse(fu_time_yrs < closests_past_aria + (length_aria) * time_increments &
                                  fu_time_yrs >= closests_past_aria
                                , 1
                                , 0)
      
      , aria_symptoms = ifelse(fu_time_yrs < closests_past_aria + (length_aria) * time_increments &
                                 fu_time_yrs >= closests_past_aria
                               , aria_symptoms[closests_aria_index]
                               , NA)
      
      , aria_severity = ifelse(fu_time_yrs < closests_past_aria + (length_aria) * time_increments &
                                 fu_time_yrs >= closests_past_aria
                               , aria_severity[closests_aria_index]
                               , NA)
    ) %>% 
    ungroup() %>% dplyr::select(-aria_time, -closests_past_aria, -closests_aria_index)
  
  
  long_data <- long_data %>%
    mutate(
      aria_symptoms = if_else(aria_symptoms == 1
                              , "symptomatic"
                              , "asymptomatic"
                              , NA))
  
  ##check how often side-effects have occurred
  long_data <- long_data %>% 
    group_by(id) %>% 
    mutate(aria_count = prior_aria_count +
             cumsum(aria_occurence)/length_aria
           , aria_count = ceiling(aria_count)
    ) %>% ungroup
  
  
  ##apply treatment decision in case you assume all aria is observed
  if(aria_all_observed == "yes"){
    long_data <- long_data %>% group_by(id) %>% 
      mutate(
        ##if second side-effect, stop treatment, take out all subsequent side-effects
        t_second_side_effect = fu_time_yrs[aria_count >= 2][1]
        , treated = if_else(fu_time_yrs >= t_second_side_effect
                            , 0
                            , treated, treated)
        
        , t_third_side_effect = fu_time_yrs[aria_count >= 3][1]
        , aria_occurence = if_else(fu_time_yrs >= t_third_side_effect
                                   , 0
                                   , aria_occurence, aria_occurence)
        , aria_severity = if_else(fu_time_yrs >= t_third_side_effect
                                  , NA
                                  , aria_severity, aria_severity)
        , aria_symptoms = if_else(fu_time_yrs >= t_third_side_effect
                                  , NA
                                  , aria_symptoms, aria_symptoms)
        
        ##For severe side-effects also stop treatment, take out all subsequent side-effects
        , t_severe_side_effect = if_else(any(aria_severity == "severe", na.rm = T)
                                         , fu_time_yrs[aria_severity == "severe" & !is.na(aria_severity)][1]
                                         , NA 
                                         , NA
        )
        , treated = if_else(fu_time_yrs >= t_severe_side_effect
                            , 0
                            , treated, treated)
        , aria_occurence = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                   , 0
                                   , aria_occurence, aria_occurence)
        , aria_severity = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                  , NA
                                  , aria_severity, aria_severity)
        , aria_symptoms = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                  , NA
                                  , aria_symptoms, aria_symptoms)
      ) %>% 
      ungroup %>% 
      mutate(
        ##during moderate aria cessate treatment
        treated = if_else(aria_severity == "moderate"
                          , 0
                          , treated
                          , treated)
        
        ##during mild aria with symptoms, cessate treatment
        , treated = if_else(aria_severity == "mild" & aria_symptoms == "symptomatic"
                            , 0
                            , treated
                            , treated)
        
      )
    
  }
  
  ##apply treatment decision in case you assume some visitation scheme is applied
  if(aria_all_observed == "no"){
    long_data <- long_data %>% 
      ##all symptomatic aria is observed
      mutate(aria_observed = ifelse(aria_symptoms == "symptomatic"
                                    , "yes"
                                    , "no")) %>%
      group_by(id) %>% 
      ##asymptomatic aria is only observed if an mri was scheduled
      mutate(
        mri_and_aria = ifelse(mri_scheduled == "yes" & aria_symptoms == "asymptomatic", "yes", "no")
        , mri_caught_aria = slide_lgl(mri_and_aria, ~ "yes" %in% .x, .before = length_aria, .complete= F)
        , aria_observed = ifelse(aria_symptoms == "asymptomatic" & mri_caught_aria
                                 , "yes"
                                 , aria_observed)) %>% 
      ungroup %>% 
      ##clean out all unobserved aria
      mutate(aria_occurence = 
               if_else(aria_observed == "no", 0, aria_occurence, aria_occurence)
             , aria_severity = 
               if_else(aria_observed == "no", NA, aria_severity, aria_severity)
             , aria_symptoms = 
               if_else(aria_observed == "no", NA, aria_symptoms, aria_symptoms)
      ) %>%
      dplyr::select(-mri_and_aria, -mri_caught_aria)
    
    ## recalculate aria count after accounting for unobserved aria
    long_data <- long_data %>% 
      group_by(id) %>% 
      mutate(
        detect_new_aria = (aria_occurence > lag(aria_occurence, default = 0))
        , aria_count = prior_aria_count +
          cumsum(detect_new_aria)) %>% ungroup %>% 
      dplyr::select(-detect_new_aria)
    
    ## apply treatment decisions
    long_data <- long_data %>% group_by(id) %>% 
      mutate(
        ##if second side-effect, stop treatment, take out all subsequent side-effects
        t_second_side_effect = fu_time_yrs[aria_count >= 2][1]
        , treated = if_else(fu_time_yrs >= t_second_side_effect
                            , 0
                            , treated, treated)
        
        , t_third_side_effect = fu_time_yrs[aria_count >= 3][1]
        , aria_occurence = if_else(fu_time_yrs >= t_third_side_effect
                                   , 0
                                   , aria_occurence, aria_occurence)
        , aria_severity = if_else(fu_time_yrs >= t_third_side_effect
                                  , NA
                                  , aria_severity, aria_severity)
        , aria_symptoms = if_else(fu_time_yrs >= t_third_side_effect
                                  , NA
                                  , aria_symptoms, aria_symptoms)
        
        ##For severe side-effects also stop treatment, take out all subsequent side-effects
        , t_severe_side_effect = if_else(any(aria_severity == "severe", na.rm = T)
                                         , fu_time_yrs[aria_severity == "severe" & !is.na(aria_severity)][1]
                                         , NA 
                                         , NA
        )
        , treated = if_else(fu_time_yrs >= t_severe_side_effect
                            , 0
                            , treated, treated)
        , aria_occurence = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                   , 0
                                   , aria_occurence, aria_occurence)
        , aria_severity = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                  , NA
                                  , aria_severity, aria_severity)
        , aria_symptoms = if_else(fu_time_yrs > (t_severe_side_effect + length_aria * time_increments)
                                  , NA
                                  , aria_symptoms, aria_symptoms)
        
      ) %>% 
      ungroup %>% 
      mutate(
        ##during moderate aria cessate treatment
        treated = if_else(aria_severity == "moderate"
                          , 0
                          , treated
                          , treated)
        
        ##during mild aria with symptoms, cessate treatment
        , treated = if_else(aria_severity == "mild" & aria_symptoms == "symptomatic"
                            , 0
                            , treated
                            , treated)
        
      )
    
  }
  
  ##adjust for the treat-to-clear scenario
  if(treatment_scenario == "ttc"){
    t_incr <- mean(diff(times))
    
    long_data$treatment_end <- time_to_clear
    #calculate how long someone has been on treatment - prior_treatment_time defined above
    long_data <- long_data %>% 
      group_by(id) %>% 
      mutate(time_on_treatment = prior_treatment_time + cumsum(treated) * t_incr - t_incr) %>% ##minus t_incr because the first timepoint is t = 0, so 0 time on treatment
      ungroup
    
    ##remove all side-effects after treatment ended
    long_data <- long_data %>% 
      group_by(id) %>% 
      mutate(aria_occurence = if_else(time_on_treatment >= treatment_end
                                      , 0
                                      , aria_occurence, aria_occurence)
             , aria_severity = if_else(time_on_treatment >= treatment_end
                                       , NA
                                       , aria_severity, aria_severity)
             , aria_symptoms = if_else(time_on_treatment >= treatment_end
                                       , NA
                                       , aria_symptoms, aria_symptoms)
      ) %>% 
      ungroup
    
    ##set treatment to 1 after treatment_end as effect persists 
    long_data <- long_data %>% 
      group_by(id) %>% 
      mutate(treated = if_else(time_on_treatment >= treatment_end
                               , 1
                               , treated, treated)) %>% 
      ungroup
    
    ##adjust time on treatment to reflect treatment stop
    long_data$time_on_treatment <-
      pmin(long_data$time_on_treatment, long_data$treatment_end)
    
  }
  
  ##remove aria death times where an aria no longer occurs after the above alterations
  long_data <- long_data %>% group_by(id) %>% 
    mutate(
      still_aria_at_reg_time = ifelse(!is.na(t_dead_aria)
                                      , aria_occurence[fu_time_yrs == t_dead_aria] == 1
                                      , F)
      , t_dead_aria = if_else(still_aria_at_reg_time
                              , t_dead_aria
                              , NA)) %>% 
    ungroup
  
  ## recalculate aria count after account for treatment decisions
  long_data <- long_data %>% 
    group_by(id) %>% 
    mutate(
      detect_new_aria = (aria_occurence > lag(aria_occurence, default = 0))
      , aria_count = prior_aria_count +
        cumsum(detect_new_aria)) %>% ungroup %>% 
    dplyr::select(-detect_new_aria)
  
  ## set mri's to occur at every visit with an ARIA
  long_data <- long_data %>% 
    mutate(mri_scheduled = ifelse(aria_occurence == 1, "yes", mri_scheduled)
           ##one more MRI after aria has cleared to confirm it has
           , aria_cleared = (aria_occurence < lag(aria_occurence))
           , mri_scheduled = if_else(aria_cleared, "yes", mri_scheduled, mri_scheduled)
    )
  
  data_return <- long_data %>% 
    dplyr::select(id, fu_time_yrs, treated, aria_count, aria_severity, aria_symptoms, mri_scheduled, t_dead_aria, any_of(c("t_discontinue", "time_on_treatment")))  %>% 
    data.frame
  
  return(data_return)
  
}

#### Treatment heterogeneity #####

## in case of presuming an all-or-nothing effect of treatment (so for some it works, and for some it doesn't)
## this function samples if people have an effect. Only used when slowing MMSE because
## otherwise people would never die in the dementia stage


treatment_heterogeneity_sampler <- function(data, slowing){
  data$treat_all_or_nothing <- rbinom(nrow(data), size = 1, prob = slowing)
  return(data)
}

#### MCI survival probabilities ####

## data - data file of person characteristics of MCI patients
## times - timepoints at which to generate survival probabilities
## joint_model - object containing the joint model covariates
## slowing - proportion (0 to 1) to slow time by
## stop_mmse - MMSE value at which treatment is assumed to stop working
## id - variable that signifies unique individuals. Used intermittently and generaly presumed to be "id"
## extension_base_haz - the baseline hazard used to extent the baseline hazard after t_split
## t_split - time after which the extension_base_haz is used
## treat_impl - "none" for no treatment, "slow_mmse" for slowing mmse
## stop_time - time (yrs) after which treatment is presumed to stop
## red_haz - "yes"/"no" indicating if the hazard function is altered in addition to slowing MMSE
## red_haz_perc - proportion (0 to 1) by which the hazard is reduced in the end
## side_effects - "yes"/"no" indicating if ARIA are included
## side_effect_data - output of aria_side_effects fucntion
## sim_vol_discontinuation - if there was voluntary treatment discontinuation sampled
## waning - proportion (0 to 1) indicating the amount by which the treatment effect is reduced every year 

predict_mci <- function(data                            
                        , times
                        , joint_model
                        , slowing = slowing
                        , stop_mmse = stop_mmse
                        , id = "id"
                        , extension_base_haz
                        , t_split
                        , treat_impl = "none"
                        , stop_time
                        , red_haz = "no"
                        , red_haz_perc = NA
                        , side_effects = "no", side_effect_data = NA
                        , sim_vol_discontinuation = "no"
                        , waning = 0
                        , treat_heterogeneity = "leaky"){
  
  ## extracting dynamic variables
  gammas_bs <- joint_model$tte$gammas_bs  
  gammas   <- joint_model$tte$gammas
  alphas <- joint_model$tte$alphas 
  knots <- joint_model$tte$knots                           
  ord_spline <- joint_model$tte$ord_spline
  
  betas_fixed <- joint_model$lmm$betas_fixed                                
  
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        
  form_gamma <- joint_model$tte$form_gamma
  
  t_jm  <- times  
  
  ##add slowing and red haz to data so it can be changed
  if(treat_heterogeneity == "leaky"){
    data$slowing <- slowing
    data$red_haz_perc <- red_haz_perc
  }
  if(treat_heterogeneity == "all_or_nothing"){
    data$slowing <- data$treat_all_or_nothing
    data$red_haz_perc <- data$treat_all_or_nothing
  }
  
  data_long_jm <- data[rep(row.names(data), each = length(t_jm)),]
  data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))   
  
  ## calculating the baseline hazard of the jm part
  bspline_matrix  <- splineDesign(knots = knots, x = times + 1e-3, ord = ord_spline, outer.ok = T) ##the offset is because otherwise at 0 it produces an incorrect log-hazard.
  base_haz_jm_log <- bspline_matrix %*% cbind(gammas_bs) %>% as.numeric 
  
  ##as the baseline hazard is extended after the run time of the model, the baseline hazard after the end of the model (t_split), is filled in the with the extension_base_haz
  base_haz_jm_log[times >= t_split] <- extension_base_haz
  
  data_long_jm$base_haz_jm_log <- rep_len(base_haz_jm_log, length.out = nrow(data_long_jm)) 
  
  ## creating model matrix for lp (lp = linear prediction)
  mm_gamma <- data_long_jm %>% 
    model.matrix(formula(form_gamma), .) 
  mm_gamma <- mm_gamma[ , !(colnames(mm_gamma) %in% c("(Intercept)", "strata"))]
  
  ##vectorise slowing & red_haz and apply waning
  if(waning != 0){
    data_long_jm$slowing <- data_long_jm$slowing * (1 - waning)^data_long_jm$fu_time_yrs
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * (1 - waning)^data_long_jm$fu_time_yrs
  }
  
  ##add the side-effects if simulated
  if(treat_impl != "none" & side_effects == "yes"){
    ##check if both dataframes line up
    if(!all(data_long_jm$id == side_effect_data$id & data_long_jm$fu_time_yrs == side_effect_data$fu_time_yrs)){
      stop("Simulation data and side-effect data don't line up 1")}
    ##add all columns except id, fu_time_yrs to long formatted data
    data_long_jm <- 
      cbind(data_long_jm
            , side_effect_data[, !(names(side_effect_data) %in% names(data_long_jm))])
    
    data_long_jm$slowing <- data_long_jm$slowing * data_long_jm$treated
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * data_long_jm$treated
  }
  
  ##treatment discontinuation resides in the side-effect function, but can also but run outside of it 
  if(treat_impl != "none" & side_effects == "no" & sim_vol_discontinuation == "yes"){
    data_long_jm$treated <- 1
    data_long_jm$treated[data_long_jm$fu_time_yrs > data_long_jm$t_discontinue] <- 0
    
    data_long_jm$slowing <- data_long_jm$slowing * data_long_jm$treated
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * data_long_jm$treated
  }
  
  #calculated mmse curve with and without treatment effect
  if(treat_impl == "none"){
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
  } 
  if(max(slowing) != 0 & treat_impl == "slow_mmse"){
    data_long_jm <- data_long_jm %>% mutate(fu_time_yrs = fu_time_yrs * (1 - slowing))
    
    ##first calculate the full mmse curve with slowed time
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
    
    ##determine when stop criteria MMSE is reached
    data_long_jm <- data_long_jm %>%
      group_by(
        .[,{{id}}]
        # id
      ) %>%
      mutate(
        # Identify time and MMSE when stop_mmse is reached
        t_adj_at_stop = ifelse(any(pred_mmse <= stop_mmse),
                               min(fu_time_yrs[pred_mmse <= stop_mmse], na.rm = TRUE)
                               , max(times))
        
        #Identify if time at stop_mmse isn't after the stop_time
        , t_adj_at_stop = ifelse(t_adj_at_stop > stop_time
                                 , stop_time
                                 , t_adj_at_stop)
        , t_real_at_stop =  ifelse(any(pred_mmse <= stop_mmse)
                                   , t_jm[which(fu_time_yrs == t_adj_at_stop)] ##selects the "real time" at which the stop MMSe is reached
                                   , max(t_jm)
        ) 
        
        # Adjust time after the MMSE decline has reached the stop point
        ## From the point where the MMSE is lower than the stop criterium, it needs to 
        ## follow a normal decline speed. Adjustment for the "real"/original time
        ## at the index of the stop_mmse needs to be made.
        ## Note to self: to understand the logic draw it out with 33% slowing of a 0:3 time series
        , fu_time_yrs = if_else(fu_time_yrs >= t_adj_at_stop
                                , fu_time_yrs / (1 - slowing) - (t_real_at_stop - t_adj_at_stop)
                                , fu_time_yrs,
        )
      )
    
    mm_beta <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    # Now recalculate the MMSE using the adjusted time
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed) +
                                           data_long_jm$re_int +
                                           data_long_jm$re_slope * data_long_jm$fu_time_yrs)
    
    ##reset time variable
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))
  }
  
  ##truncate MMSE at real values
  data_long_jm$pred_mmse[data_long_jm$pred_mmse < 0] <- 0 
  data_long_jm$pred_mmse[data_long_jm$pred_mmse > 30] <- 30 
  
  ## calculating the linear predictor
  data_long_jm$lp_jm <- as.numeric(mm_gamma %*% cbind(gammas)) + data_long_jm$pred_mmse * alphas
  
  ## calculating hazard for the JM
  data_long_jm$haz <- NA
  data_long_jm$haz <- exp(data_long_jm$base_haz_jm_log + data_long_jm$lp_jm) 
  
  ##apply hazard reduction to overall hazard
  if(red_haz == "yes" & treat_impl != "none"){
    data_long_jm <- data_long_jm %>% 
      mutate(haz = if_else(pred_mmse >= stop_mmse
                           , haz * (1 - red_haz_perc)
                           , haz)
      )
  }
  
  ##sum the hazard over time for cumulative hazard
  data_long_jm <- data_long_jm %>% 
    group_by(
      .[,{{id}}]
    ) %>% 
    mutate(cumhaz = as.numeric(cumtrapz(fu_time_yrs, haz))) %>% 
    ungroup()
  
  ## survival prob jm 
  data_long_jm <- data_long_jm %>% mutate(surv_prob = as.numeric(exp(- cumhaz)))
  
  ##export specific variables
  data_return <- data_long_jm %>% 
    dplyr::select(id, fu_time_yrs, surv_prob, pred_mmse, i_age_1, i_sex, i_age_1_scaled, i_living
                  , any_of("treat_all_or_nothing"))
  
  if(side_effects == "yes"){
    added_columns <- data_long_jm %>% 
      dplyr::select(all_of(names(side_effect_data)))
    
    added_columns <- added_columns %>% arrange(id, fu_time_yrs)
    data_return <- data_return %>% arrange(id, fu_time_yrs)
    if(!all(data_return$id == added_columns$id & data_return$fu_time_yrs == added_columns$fu_time_yrs)){
      stop("Simulation data and side-effect data don't line up 2")}
    data_return <- cbind(data_return, added_columns[, !(names(added_columns) %in% names(data_return))])
    # data_return <- merge(data_return, added_columns)
  }
  
  return(data_return)
}

#### Dem sampling random effects ####
## samples random effects  in the dementia stage depending on whether people came in from the MCI stage or started in the dementia stage

## data - data at the dementia stage
## joint_model - dementia joint model
## from_mci - simulation started in MCI or in dementia

dementia_draw_random_effects <- function(data, joint_model, from_mci = "yes"){
  ## extracting dynamic variables
  betas_fixed <- joint_model$lmm$betas_fixed                               
  
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        
  
  ##generation random slope
  if(from_mci == "yes"){
    ##Calculate intercept MMSE so I can subtract it from the calculations
    mm_lme <- model.matrix(form_beta_fixed, data = mutate(data, fu_time_yrs = 0)) # What does the model.matrix function do? Create a subset of data to fit the model formula 
    
    data$mmse_intercept <- as.numeric(mm_lme %*% cbind(betas_fixed))
    
    ##random intercept is equal to difference between MMSE at transition and MMSE based on fixed effect
    data$re_int <- data$mmse_baseline - data$mmse_intercept
    
    ##gives the mean value the slope is supposed to have based on the random intercept
    lt_mat <- ltMatrices(matrix(c(joint_model$re$re_int, joint_model$re$re_cov, joint_model$re$re_slope)), diag = T) 
    cond_mean <- cond_mvnorm(chol = lt_mat, which_given = 1, given = matrix(data$re_int, ncol = nrow(data)))
    data$re_slope <- rnorm(nrow(data), mean = cond_mean$mean, sd = sqrt(cond_mean$chol))
    
    data <- data %>% dplyr::select(-mmse_intercept)
    
  }else{
    ##generates random intercepts and slopes
    sigma <- matrix(NA, 2, 2)
    sigma[1,1] <- joint_model$re$re_int
    sigma[1,2] <- sigma[2,1] <- joint_model$re$re_cov
    sigma[2,2] <- joint_model$re$re_slope
    
    re_dem <- mvrnorm(nrow(data), mu = c(0,0), Sigma = sigma)
    
    data$re_int <- re_dem[,1]
    data$re_slope <- re_dem[,2]
  }
  
  return(data)
}


#### Dem survival probabilities ####

## function that takes a weibull scale and shape and turns it into a hazard. Based of the wikipedia formula
weibull_haz <- function(t, scale, shape){shape/scale * (t/scale) ^ (shape - 1)}

## data - data file of person characteristics of MCI patients
## times - timepoints at which to generate survival probabilities
## joint_model - object containing the joint model covariates
## slowing - proportion (0 to 1) to slow time by
## stop_mmse - MMSE value at which treatment is assumed to stop working
## id - variable that signifies unique individuals. Used intermittently and generaly presumed to be "id"
## extension_base_haz - the baseline hazard used to extent the baseline hazard after t_split
## t_split - time after which the weibull extension model is used
## ext_model - weibull extension model object
## stop_time - time (yrs) after which treatment is presumed to stop
## pred_part - prediction probability of institutionalisation or death
## from_mci - "yes" indicates simulation started in MCI "no" that it started in dementia
## red_haz - "yes"/"no" indicating if the hazard function is altered in addition to slowing MMSE
## red_haz_perc - proportion (0 to 1) by which the hazard is reduced in the end
## side_effects - "yes"/"no" indicating if ARIA are included
## side_effect_data - output of aria_side_effects fucntion
## waning - proportion (0 to 1) indicating the amount by which the treatment effect is reduced every year 
## sim_vol_discontinuation - simulate if people voluntarily stop for treatment
## treat_heterogeneity - simulate if all people have the same effect (leaky), or a proportion have 100% effect and a proportion 0% (all or nothing)

prediction_dementia <- function(data                                     
                                , joint_model                                                       
                                , times                                    
                                , slowing = 0
                                , stop_mmse = 20
                                , t_split = 4                                  
                                , id = "id"                                       
                                , ext_model
                                , pred_part = "inst" ##set if time to institutionalisation or death are calculated
                                , from_mci = "yes" ##if yes, new random effects are generated conditional on the mmse at conversion
                                , treat_impl = "none"
                                , stop_time
                                , red_haz = "no"
                                , red_haz_perc = NA
                                , waning = 0 
                                , side_effects = "no", side_effect_data 
                                , treat_heterogeneity = "leaky"
){
  ## extracting dynamic variables
  gammas_bs <- joint_model$tte[[paste0("gammas_bs_", pred_part)]]
  
  gammas   <- joint_model$tte$gammas    
  
  alphas <- ifelse(pred_part == "inst", sum(joint_model$tte$alphas), joint_model$tte$alphas[1])
  
  betas_fixed <- joint_model$lmm$betas_fixed                               
  
  knots <- joint_model$tte$knots[[1]]
  ord_spline <- joint_model$tte$ord_spline                                        
  
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        
  form_gamma <- joint_model$tte$form_gamma
  
  ## extension model variables
  ext_shape_coef <- ext_model$ext_shape_coef 
  ext_scale_coef  <- ext_model$ext_scale_coef
  form_scale <- ext_model$form_scale
  
  t_jm  <- times  # times for the joint model
  t_ext <- times # times for the extension model
  
  ##add slowing and red haz to data so it can be changed
  if(treat_heterogeneity == "leaky"){
    data$slowing <- slowing
    data$red_haz_perc <- red_haz_perc
  }
  if(treat_heterogeneity == "all_or_nothing"){
    data$slowing <- data$treat_all_or_nothing
    data$red_haz_perc <- data$treat_all_or_nothing
  }
  
  ## turning data into long format jm
  data_long_jm <- data[rep(row.names(data), each = length(t_jm)),] ##typo fixed length
  data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))   
  
  ## calculating the baseline hazard of the jm part
  bspline_matrix  <- splineDesign(knots = knots, x = times + 1e-3, ord = ord_spline, outer.ok = T) ##the offset is because otherwise at 0 it produces an incorrect log-hazard.
  base_haz_jm_log <- bspline_matrix %*% cbind(gammas_bs) %>% as.numeric 
  
  data_long_jm$base_haz_jm_log <- rep_len(base_haz_jm_log, length.out = nrow(data_long_jm)) 
  
  ## creating model matrix for lp (lp = linear prediction)
  mm_gamma <- data_long_jm %>% 
    mutate(strata = if_else(pred_part == "inst", 1, 0)) %>% 
    model.matrix(formula(form_gamma), .) 
  mm_gamma <- mm_gamma[ , !(colnames(mm_gamma) %in% c("(Intercept)", "strata"))] 
  
  ##check if from MCI to adjust the stopping time and apply waning
  if(from_mci == "yes"){
    data_long_jm$stop_time <- stop_time - data_long_jm$time_in_mci
    data_long_jm$stop_time <- ifelse(data_long_jm$stop_time < 0
                                     , 0 
                                     , data_long_jm$stop_time)
    
  }
  
  ##vectorise slowing & red_haz and apply waning
  if(waning != 0){
    
    if(from_mci == "yes"){
      data_long_jm$slowing <- data_long_jm$slowing * (1 - waning)^data_long_jm$time_in_mci
      data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * (1 - waning)^data_long_jm$time_in_mci
    }
    
    data_long_jm$slowing <- data_long_jm$slowing * (1 - waning)^data_long_jm$fu_time_yrs
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * (1 - waning)^data_long_jm$fu_time_yrs
    
  }
  
  ##generate side-effects
  if(treat_impl != "none" & side_effects == "yes"){
    ##check if both dataframes line up
    if(!all(data_long_jm$id == side_effect_data$id & 
            data_long_jm$fu_time_yrs == side_effect_data$fu_time_yrs)){
      stop("Simulation data and side-effect data don't line up 1")
    }
    ##add all columns except id, fu_time_yrs to long formatted data
    # data_long_jm <- merge(data_long_jm, side_effect_data)
    data_long_jm <-
      cbind(data_long_jm
            , side_effect_data[, !(names(side_effect_data) %in% names(data_long_jm))])
    
    data_long_jm$slowing <- data_long_jm$slowing * data_long_jm$treated
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * data_long_jm$treated
  }
  
  ##treatment discontinuation resides in the side-effect function, but can also but run outside of it 
  if(treat_impl != "none" & side_effects == "no" & sim_vol_discontinuation == "yes"){
    data_long_jm$treated <- 1
    data_long_jm$treated[(data_long_jm$fu_time_yrs + data_long_jm$time_in_mci) > data_long_jm$t_discontinue] <- 0
    
    data_long_jm$slowing <- data_long_jm$slowing * data_long_jm$treated
    data_long_jm$red_haz_perc <- data_long_jm$red_haz_perc * data_long_jm$treated
  }
  
  #calculated mmse curve in several cases of slowing
  if(treat_impl == "none"){
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
  } 
  
  if(max(slowing) != 0 & treat_impl == "slow_mmse"){
    data_long_jm <- data_long_jm %>% mutate(fu_time_yrs = fu_time_yrs * (1 - slowing))
    
    ##first calculate the full mmse curve with slowed time
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long_jm$re_int + data_long_jm$re_slope * data_long_jm$fu_time_yrs
    
    ##determine when stop criteria MMSE is reached
    data_long_jm <- data_long_jm %>%
      group_by(
        # .[,{{id}}]
        id
      ) %>%
      mutate(
        # Identify time and MMSE when stop_mmse is reached
        t_adj_at_stop = ifelse(any(pred_mmse <= stop_mmse),
                               min(fu_time_yrs[pred_mmse <= stop_mmse], na.rm = TRUE)
                               , max(times))
        
        #Identify if time at stop_mmse isn't after the stop_time
        , t_adj_at_stop = ifelse(t_adj_at_stop > stop_time
                                 , min(fu_time_yrs[fu_time_yrs > stop_time]) ##select first timepoint after the stop time to be the time after which slowing doesn't occur anymore
                                 , t_adj_at_stop)
        , t_real_at_stop =  ifelse(any(pred_mmse <= stop_mmse)
                                   , t_jm[which(fu_time_yrs == t_adj_at_stop)] ##selects the "real time" at which the stop MMSe is reached
                                   , max(t_jm)
        ) 
        
        # Adjust time after the MMSE decline has reached the stop point
        ## From the point where the MMSE is lower than the stop criterium, it needs to 
        ## follow a normal decline speed. Adjustment for the "real"/original time
        ## at the index of the stop_mmse needs to be made.
        ## Note to self: to understand the logic draw it out with 33% slowing of a 0:3 time series
        , fu_time_yrs = if_else(fu_time_yrs >= t_adj_at_stop
                                , fu_time_yrs / (1 - slowing) - (t_real_at_stop - t_adj_at_stop)
                                , fu_time_yrs
        )
      )
    
    mm_beta <- model.matrix(formula(form_beta_fixed), data = data_long_jm)
    
    # Now recalculate the MMSE using the adjusted time
    data_long_jm$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed) +
                                           data_long_jm$re_int +
                                           data_long_jm$re_slope * data_long_jm$fu_time_yrs)
    
    ##reset time variable
    data_long_jm$fu_time_yrs <- rep_len(t_jm, length.out = nrow(data_long_jm))
  }
  
  ##truncate MMSE at natural bounds
  data_long_jm$pred_mmse[data_long_jm$pred_mmse < 0] <- 0 
  data_long_jm$pred_mmse[data_long_jm$pred_mmse > 30] <- 30 
  
  ## calculating the linear predictor for the jm
  data_long_jm$lp_jm <- as.numeric(mm_gamma %*% cbind(gammas)) + data_long_jm$pred_mmse * alphas 
  
  ## calculating hazard for the JM part
  data_long_jm$haz <- NA
  data_long_jm$haz <- exp(data_long_jm$base_haz_jm_log + data_long_jm$lp_jm) 
  
  # hazard from the extension model
  ## First getting out the MMSE at split point from the JM and merging in into the data
  data_jm_mmse <- data_long_jm %>% 
    group_by(
      # .[,{{id}}]
      id
    ) %>% 
    slice(which.min(abs(fu_time_yrs - t_split))) %>% ungroup %>% 
    dplyr::select(id, pred_mmse) %>% rename(v_mmse = pred_mmse)
  
  data <- data %>% merge(., data_jm_mmse)
  
  # calculating shape and scale for Weibull
  data <- data %>% mutate(strata = pred_part)
  
  mm1  <- data.frame(c1 = 1, c2 = ifelse(data$strata == "inst", 1, 0)) 
  if(length(ext_shape_coef) == 1) {mm1 <- data.frame(c1 = 1)} 
  
  data$ext_shape <- as.matrix(mm1) %*% cbind(ext_shape_coef) %>%  as.numeric %>% exp 
  
  data$ext_scale <- data %>% 
    mutate(strata = if_else(pred_part == "inst", 1, 0)
           , i_age_1 = i_age_1 + t_split) %>% 
    model.matrix(form_scale, data = .) %*% cbind(ext_scale_coef) %>%  as.numeric %>% exp
  
  ## turning data into long format gamma model
  data_long_ext <- data[rep(row.names(data), each = length(t_ext)),] 
  data_long_ext$fu_time_yrs <- rep_len(t_ext, length.out = nrow(data_long_ext))
  
  data_long_ext$haz <- 
    weibull_haz(t = data_long_ext$fu_time_yrs, 
                shape = data_long_ext$ext_shape,
                scale = data_long_ext$ext_scale)
  
  ## adjusting the time in the extension model the reflect time from dementia start
  data_long_ext <- data_long_ext %>% 
    mutate(fu_time_yrs = fu_time_yrs + t_split)
  
  ## binding rows together
  data_long_ext <- data_long_ext %>% rename(pred_mmse = v_mmse)
  col_select <- c("id", "fu_time_yrs", "haz")
  data_long <- rbind(data_long_jm[data_long_jm$fu_time_yrs < t_split, col_select]
                     , data_long_ext[data_long_ext$fu_time_yrs <= max(times), col_select]) 
  
  ## Merge in the predicted mmse at each time point
  data_long <- data_long_jm %>% dplyr::select(id, fu_time_yrs, pred_mmse, red_haz_perc) %>% 
    merge(data_long, ., by = c("id", "fu_time_yrs"))
  
  ## Reduce hazard if this treatment option is selected
  if(red_haz == "yes" & treat_impl != "none"){
    
    data_long <- data_long %>% 
      group_by(
        # .[,{{id}}]
        id
      ) %>% 
      mutate(haz = ifelse(pred_mmse >= stop_mmse
                          , haz * (1 - red_haz_perc)
                          , haz)) %>% 
      ungroup
  }
  
  ## calculate cumulative hazard by person
  data_long <- data_long %>% 
    arrange(id, fu_time_yrs) %>% 
    group_by(
      .[,{{id}}]
    ) %>%
    mutate(cumhaz = as.numeric(cumtrapz(fu_time_yrs, haz))) %>% 
    ungroup()
  
  ## Calculate survival probability
  data_long <- data_long %>% mutate(surv_prob = as.numeric(exp(- cumhaz)))
  
  ## merge the survival data with some patient characteristics needed
  data <- data %>% 
    dplyr::select(id, i_age_1, i_sex, i_living) %>% 
    merge(data_long, ., by = "id", all.y = T) %>% arrange(id, fu_time_yrs)
  
  ##select what data to output
  data_return <- data %>% 
    dplyr::select(id, fu_time_yrs, surv_prob, i_age_1, i_sex, pred_mmse, i_living, haz)
  
  if(side_effects == "yes"){
    added_columns <- data_long_jm %>% 
      dplyr::select(all_of(names(side_effect_data)))
    
    added_columns <- added_columns %>% arrange(id, fu_time_yrs)
    data_return <- data_return %>% arrange(id, fu_time_yrs)
    if(!all(data_return$id == added_columns$id & all.equal(data_return$fu_time_yrs, added_columns$fu_time_yrs))){
      stop("Simulation data and side-effect data don't line up 2")}
    data_return <- cbind(data_return, added_columns[, !(names(added_columns) %in% names(data_return))])
    # data_return <- merge(data_return, added_columns) ##cbind doesn't work here because the times don't exactly match due to the integer addition of time_split
  }
  
  return(data_return)
  
}

#### Institutionalisation survival ####
## data - data file of person characteristics of MCI patients
## times - timepoints at which to generate survival probabilities
## model - object containing the weibull covariates
## id - variable that signifies unique individuals. Used intermittently and generaly presumed to be "id"

prediction_institution <- function(data
                                   , model
                                   , times
                                   , id = "id"){
  mm <- model.matrix(model$form_scale, data)
  data$lp <- as.numeric(mm %*% model$scale_coef)
  
  data <- data[rep(row.names(data), each = length(times)),]
  data$fu_time_yrs <- rep_len(times, length.out = nrow(data))
  data$surv_prob <- 1 - pweibull(data$fu_time_yrs, shape = exp(model$shape_coef), scale = exp(data$lp))
  
  # data$fu_time_yrs <- rweibull(nrow(data), shape = exp(model$shape_coef), scale = exp(data$lp))
  return(data)
}


#### Weibull survival ####
## data - data file of person characteristics of MCI patients
## times - timepoints at which to generate survival probabilities
## model - weibull model containing shape and scale parameters
## joint_model - object containing the joint model covariates
## slowing - proportion (0 to 1) to slow time by
## stop_mmse - MMSE value at which treatment is assumed to stop working
## id - variable that signifies unique individuals. Used intermittently and generaly presumed to be "id"
## stop_time - time (yrs) after which treatment is presumed to stop
## pred_part - prediction probability of institutionalisation or death
## from_mci - "yes" indicates simulation started in MCI "no" that it started in dementia
## red_haz - "yes"/"no" indicating if the hazard function is altered in addition to slowing MMSE
## red_haz_perc - proportion (0 to 1) by which the hazard is reduced in the end
## side_effects - "yes"/"no" indicating if ARIA are included
## side_effect_data - output of aria_side_effects fucntion
## waning - proportion (0 to 1) indicating the amount by which the treatment effect is reduced every year 
## sim_vol_discontinuation - simulate if people voluntarily stop for treatment
## treat_heterogeneity - simulate if all people have the same effect (leaky), or a proportion have 100% effect and a proportion 0% (all or nothing)
## dementia_sim - indicate if the times are for the MCi ("no"), or dementia ("yes") stage

predict_weibull_time <- function(data
                                 , model
                                 , joint_model
                                 , times
                                 , slowing = slowing
                                 , stop_mmse = stop_mmse
                                 , id = "id"
                                 , treat_impl = "none"
                                 , stop_time
                                 , red_haz = "no"
                                 , red_haz_perc = NA
                                 , side_effects = "no", side_effect_data = NA
                                 , sim_vol_discontinuation = "no"
                                 , waning = 0
                                 , treat_heterogeneity = "leaky"
                                 , dementia_sim
                                 , pred_part = "inst" ##set if time to institutionalisation or death are calculated
                                 , from_mci = "yes" ##if yes, new random effects are generated conditional on the mmse at conversion
){
  # model <- mci_hazard_model; data <- data; dementia_sim <- "no"; from_mci <- "yes";
  # pred_part <- "inst"; side_effect_data <- mci_aria; side_effects <- "no"; treat_impl <- "none";
  # treat_impl <- "slow_mmse"
  ## extension model variables
  wei_shape_coef <- model$wei_shape_coef 
  wei_scale_coef  <- model$wei_scale_coef
  form_scale <- model$form_scale
  
  ## extracting dynamic variables
  betas_fixed <- joint_model$lmm$betas_fixed                              
  form_beta_fixed <- joint_model$lmm$form_beta_fixed                                        
  
  ##add slowing and red haz to data so it can be changed
  if(treat_heterogeneity == "leaky"){
    data$slowing <- slowing
    data$red_haz_perc <- red_haz_perc
  }
  if(treat_heterogeneity == "all_or_nothing"){
    data$slowing <- data$treat_all_or_nothing
    data$red_haz_perc <- data$treat_all_or_nothing
  }
  
  ##for dementia model, add which outcome is of interest, then calculate shape and scale
  if(dementia_sim == "yes"){
    data <- data %>% mutate(strata = pred_part)
    
    data$ext_shape <- wei_shape_coef %>%  as.numeric %>% exp 
    
    data$ext_scale <- data %>% 
      mutate(strata = if_else(pred_part == "inst", 1, 0)) %>% 
      model.matrix(form_scale, data = .) %*% cbind(wei_scale_coef) %>%  as.numeric %>% exp
    
  }
  
  if(dementia_sim == "no"){
    data <- data %>% mutate(strata = pred_part)
    
    data$ext_shape <- wei_shape_coef %>%  as.numeric %>% exp 
    
    data$ext_scale <- data %>% 
      model.matrix(form_scale, data = .) %*% cbind(wei_scale_coef) %>%  as.numeric %>% exp
    
  }
  
  ## turning data into long format jm
  data_long <- data[rep(row.names(data), each = length(times)),] ##typo fixed length
  data_long$fu_time_yrs <- rep_len(times, length.out = nrow(data_long))   
  
  ##check if from MCI to adjust the stopping time and apply waning
  if(from_mci == "yes" & dementia_sim == "yes"){
    data_long$stop_time <- stop_time - data_long$time_in_mci
    data_long$stop_time <- ifelse(data_long$stop_time < 0
                                  , 0 
                                  , data_long$stop_time)
    
  }
  
  ##vectorise slowing & red_haz and apply waning
  if(waning != 0){
    
    if(from_mci == "yes" & dementia_sim == "yes"){
      data_long$slowing <- data_long$slowing * (1 - waning)^data_long$time_in_mci
      data_long$red_haz_perc <- data_long$red_haz_perc * (1 - waning)^data_long$time_in_mci
    }
    
    data_long$slowing <- data_long$slowing * (1 - waning)^data_long$fu_time_yrs
    data_long$red_haz_perc <- data_long$red_haz_perc * (1 - waning)^data_long$fu_time_yrs
    
  }
  
  ##add side-effects
  if(treat_impl != "none" & side_effects == "yes"){
    ##check if both dataframes line up
    if(!all(data_long$id == side_effect_data$id & 
            data_long$fu_time_yrs == side_effect_data$fu_time_yrs)){
      stop("Simulation data and side-effect data don't line up 1")
    }
    ##add all columns except id, fu_time_yrs to long formatted data
    # data_long <- merge(data_long, side_effect_data)
    data_long <-
      cbind(data_long
            , side_effect_data[, !(names(side_effect_data) %in% names(data_long))])
    
    data_long$slowing <- data_long$slowing * data_long$treated
    data_long$red_haz_perc <- data_long$red_haz_perc * data_long$treated
  }
  
  ##treatment discontinuation resides in the side-effect function, but can also but run outside of it 
  if(treat_impl != "none" & side_effects == "no" & sim_vol_discontinuation == "yes"){
    data_long$treated <- 1
    data_long$treated[(data_long$fu_time_yrs + data_long$time_in_mci) > data_long$t_discontinue] <- 0
    
    data_long$slowing <- data_long$slowing * data_long$treated
    data_long$red_haz_perc <- data_long$red_haz_perc * data_long$treated
  }
  
  ##calculate MMSE - not used in hazard function only for time purposes
  #calculated mmse curve in several cases of slowing
  if(treat_impl == "none"){
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long)
    
    data_long$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) + 
      data_long$re_int + data_long$re_slope * data_long$fu_time_yrs
  } 
  
  if(max(slowing) != 0 & treat_impl == "slow_mmse"){
    data_long <- data_long %>% mutate(fu_time_yrs = fu_time_yrs * (1 - slowing))
    
    ##first calculate the full mmse curve with slowed time
    mm_beta  <- model.matrix(formula(form_beta_fixed), data = data_long)
    
    data_long$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed)) +
      data_long$re_int + data_long$re_slope * data_long$fu_time_yrs
    
    ##determine when stop criteria MMSE is reached
    data_long <- data_long %>%
      group_by(
        # .[,{{id}}]
        id
      ) %>%
      mutate(
        # Identify time and MMSE when stop_mmse is reached
        t_adj_at_stop = ifelse(any(pred_mmse <= stop_mmse),
                               min(fu_time_yrs[pred_mmse <= stop_mmse], na.rm = TRUE)
                               , max(times))
        
        #Identify if time at stop_mmse isn't after the stop_time
        , t_adj_at_stop = ifelse(t_adj_at_stop > stop_time
                                 , min(fu_time_yrs[fu_time_yrs > stop_time]) ##select first timepoint after the stop time to be the time after which slowing doesn't occur anymore
                                 , t_adj_at_stop)
        , t_real_at_stop =  ifelse(any(pred_mmse <= stop_mmse)
                                   , times[which(fu_time_yrs == t_adj_at_stop)] ##selects the "real time" at which the stop MMSe is reached
                                   , max(times)
        ) 
        
        # Adjust time after the MMSE decline has reached the stop point
        ## From the point where the MMSE is lower than the stop criterium, it needs to 
        ## follow a normal decline speed. Adjustment for the "real"/original time
        ## at the index of the stop_mmse needs to be made.
        ## Note to self: to understand the logic draw it out with 33% slowing of a 0:3 time series
        , fu_time_yrs = if_else(fu_time_yrs >= t_adj_at_stop
                                , fu_time_yrs / (1 - slowing) - (t_real_at_stop - t_adj_at_stop)
                                , fu_time_yrs
        )
      )
    
    mm_beta <- model.matrix(formula(form_beta_fixed), data = data_long)
    
    # Now recalculate the MMSE using the adjusted time
    data_long$pred_mmse <- as.numeric(mm_beta %*% cbind(betas_fixed) + 
                                        data_long$re_int + 
                                        data_long$re_slope * data_long$fu_time_yrs
    )
    
    ##reset time variable
    data_long$fu_time_yrs <- rep_len(times, length.out = nrow(data_long))
  }
  
  ##truncate MMSE at natural bounds
  data_long$pred_mmse[data_long$pred_mmse < 0] <- 0 
  data_long$pred_mmse[data_long$pred_mmse > 30] <- 30 
  
  ## calculate hazard
  data_long$haz <- 
    weibull_haz(t = data_long$fu_time_yrs,
                shape = data_long$ext_shape,
                scale = data_long$ext_scale)
  
  ## Reduce hazard if this treatment option is selected
  if(red_haz == "yes" & treat_impl != "none"){
    
    data_long <- data_long %>% 
      group_by(
        # .[,{{id}}]
        id
      ) %>% 
      mutate(haz = ifelse(pred_mmse >= stop_mmse
                          , haz * (1 - red_haz_perc)
                          , haz)) %>% 
      ungroup
  }
  
  ## calculate cumulative hazard by person
  data_long <- data_long %>% 
    arrange(id, fu_time_yrs) %>% 
    group_by(
      # .[,{{id}}]
      id
    ) %>%
    mutate(cumhaz = as.numeric(cumtrapz(fu_time_yrs, haz))) %>% 
    ungroup()
  
  ## Calculate survival probability
  data_long <- data_long %>% mutate(surv_prob = as.numeric(exp(- cumhaz)))
  
  ##select what data to output
  data_return <- data_long %>% 
    arrange(id, fu_time_yrs) %>% 
    dplyr::select(id, fu_time_yrs, surv_prob, i_age_1, i_sex, pred_mmse, i_living, haz)
  
  if(side_effects == "yes"){
    added_columns <- data_long %>% 
      dplyr::select(all_of(names(side_effect_data)))
    
    added_columns <- added_columns %>% arrange(id, fu_time_yrs)
    data_return <- data_return %>% arrange(id, fu_time_yrs)
    if(!all(data_return$id == added_columns$id & all.equal(data_return$fu_time_yrs, added_columns$fu_time_yrs))){
      stop("Simulation data and side-effect data don't line up 2")}
    data_return <- cbind(data_return, added_columns[, !(names(added_columns) %in% names(data_return))])
    # data_return <- merge(data_return, added_columns) ##cbind doesn't work here because the times don't exactly match due to the integer addition of time_split
  }
  
  return(data_return)
}
