##loading packages
if(!require("pacman")) install.packages("pacman")
pacman::p_load("here", "dplyr", "doParallel")

##setting up simulation data.frame
simulation_input <- data.frame(sim_num = NA, slowing = NA, stop_mmse = NA)

##Percentage slowing of MMSE to be investigated
slow_opt <- c(0.3)

##MMSE at which treatment will be stopped in dementia
stop_opt <- 20

##treatment options
treat_opt <- c("none", "slow_mmse")

##reduction in hazard options
red_haz_opt <- c("no", "yes")
red_haz_perc <- c(0, .30)

##If treatments should modify probability of dieing in the dementia stage
apply_to_death <- c("yes")

##Time after which treatment should be stopped for everyone 
stop_time <- c(99)

## stratification by stating age
age_options <- c(NA, 60, 70, 80)

## stratification by sex
sex_options <- c(NA, "m", "f")

## stratification by decline speed
speed_options <- c(NA, "Slow", "Medium", "Fast")

## Parametric sensitivity analysis
parametric_sens_opt <- "no"

##number of simulations per scenario 
n_sim <- 1

##create the various simulation options
simulation_input <- 
  expand.grid(slowing = slow_opt, stop_mmse = stop_opt, treat_impl = treat_opt
              , stop_time = stop_time
              , red_haz = red_haz_opt
              , red_haz_perc = red_haz_perc
              , apply_to_death = apply_to_death
              , limit_by_speed = speed_options
              , age_set = age_options
              , sex_set = sex_options
              , parametric_sens = parametric_sens_opt)
simulation_input <- simulation_input %>%
  mutate(slowing = if_else(treat_impl == "none", 0, slowing)) %>% ##
  subset(!(red_haz == "yes" & red_haz_perc == 0)) %>% ##take out option where no slowing is applied
  subset(!(red_haz == "no" & red_haz_perc != 0)) %>% ##take out option where no slowing is applied
  subset(!(treat_impl == "none" & red_haz == "yes" )) %>% ##can't reduce hazard in no-treatment simulation
  filter(is.na(age_set) & is.na(sex_set) |
           is.na(age_set) & is.na(limit_by_speed) |
           is.na(sex_set) & is.na(limit_by_speed)) ## to limit simulations reduce overlapping limitations

##Duplicate simulation to garantee stability in results
simulation_input <- simulation_input[rep(1:nrow(simulation_input), each = n_sim), ]
simulation_input$sim_num <- 1:nrow(simulation_input)

##set outcomes to be collected in simulation
simulation_input$t_mci <- NA
simulation_input$t_mild <- NA
simulation_input$t_moderate <- NA
simulation_input$t_severe <- NA
simulation_input$t_inst <- NA
simulation_input$start_n <- NA
simulation_input$dead_mci <- NA
simulation_input$dead_dem_com <- NA

write.csv(simulation_input, here("Simulation Output", "results sim.csv"), row.names = F)

##setting up cycle dataframe
cycle_framework <- 
  data.frame(years = NA, community_mci = NA, community_mild = NA, community_moderate = NA
             , community_severe = NA, institutionalization = NA, death = NA
             , slowing = NA, stop_mmse = NA, treat_impl = NA, stop_time = NA
             , red_haz = NA, red_haz_perc = NA
             , apply_to_death = NA, limit_by_speed = NA, age_set = NA, sex_set = NA, parametric_sens = NA
            , sim_num = NA)
write.csv(cycle_framework, here("Simulation Output", "cycle sim data.csv"), row.names = F)

##supplying a single example patient for the simulations
mci_sim_pt <-  data.frame(i_sex = c("m", "f"), i_age_1 = 65, i_age_1_scaled = 0
                        , csf_ptau_log_scaled = 0, csf_ab42_scaled = 0, m_mta_lr = 1, v_mmse = 27
                        , i_living = "zelfstandig met partner/gezin" ##Dutch for living with partner/family)
)
saveRDS(mci_sim_pt, here("Simulation Dataset", "example pt.RDS")) ##you have to change the filename in the "Microsimulation.R" file accordingly 

sim_results <- read.csv(here("Simulation Output", "results sim.csv"))

##parallelisation possible to speed up simulations. Each run takes approximately 4-5gb ram, so size cores accordingly
# registerDoParallel(cores = 4)
n_iter <- sum(is.na(sim_results$t_mci) ) + 4

foreach(1:n_iter, .packages = "here") %dopar%{
  source(here("Microsimulation.R"), echo = F)
}

doParallel::stopImplicitCluster()

sim_results <- read.csv(here("Simulation Output", "results sim.csv"))
sim_results$t_mci %>% is.na %>% table
sim_results <- sim_results %>% mutate(t_dem_com = t_mild + t_moderate + t_severe)

## check output
sim_results %>% 
  # subset(start_n != 1000) %>% 
  subset(is.na(limit_by_speed) & is.na(age_set) & is.na(sex_set)) %>% 
  group_by(slowing, treat_impl, apply_to_death, red_haz, red_haz_perc) %>% 
  summarise(t_mci = mean(t_mci, na.rm =T)
            , t_mild = mean(t_mild, na.rm = T)
            , t_moderate = mean(t_moderate, na.rm = T)
            , t_severe = mean(t_severe, na.rm = T)
            , t_dem_com = mean(t_mild + t_moderate + t_severe, na.rm = T)
            , t_total = mean(t_mci + t_mild + t_moderate + t_severe + t_inst, na.rm = T)
            , t_inst = mean(t_inst, na.rm = T)
            , dead_mci = mean(dead_mci, na.rm = T)
            , dead_dem_com = mean(dead_dem_com, na.rm = T)
            , n_inst = mean(start_n - dead_mci - dead_dem_com, na.rm = T)) %>% data.frame

